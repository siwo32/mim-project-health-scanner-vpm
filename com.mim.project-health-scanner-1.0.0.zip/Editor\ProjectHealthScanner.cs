// Project Health Scanner
// Unity 2022.3+ / Editor-only / no external package dependencies.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Profiling;
using UnityEngine.SceneManagement;
using Debug = UnityEngine.Debug;
using Object = UnityEngine.Object;

namespace ProjectHealthScanner
{
    internal enum HealthSeverity
    {
        Info,
        Warning,
        Critical
    }

    [Serializable]
    internal sealed class HealthFinding
    {
        public HealthSeverity severity;
        public string category;
        public string title;
        public string detail;
        public string recommendation;
        public string assetPath;
        public int instanceId;
        public bool safeFix;
        public string fixKind;
        public long sizeBytes;
    }

    [Serializable]
    internal sealed class HealthReport
    {
        public string unityVersion;
        public string projectPath;
        public string scannedAt;
        public double elapsedSeconds;
        public int score;
        public List<HealthFinding> findings = new List<HealthFinding>();
    }

    [InitializeOnLoad]
    internal static class ProjectHealthSessionMonitor
    {
        internal sealed class LogBurst
        {
            public string message;
            public LogType type;
            public int count;
        }

        private sealed class TimedLog
        {
            public double time;
            public string message;
            public LogType type;
        }

        private sealed class RefreshEvent
        {
            public double time;
            public int changedAssets;
        }

        private static readonly Queue<TimedLog> Logs = new Queue<TimedLog>();
        private static readonly Queue<RefreshEvent> Refreshes = new Queue<RefreshEvent>();

        static ProjectHealthSessionMonitor()
        {
            Application.logMessageReceived -= OnLog;
            Application.logMessageReceived += OnLog;
        }

        private static void OnLog(string condition, string stackTrace, LogType type)
        {
            if (string.IsNullOrWhiteSpace(condition))
                return;

            Logs.Enqueue(new TimedLog
            {
                time = EditorApplication.timeSinceStartup,
                message = NormalizeLog(condition),
                type = type
            });
            Trim();
        }

        internal static void RecordRefresh(int changedAssets)
        {
            Refreshes.Enqueue(new RefreshEvent
            {
                time = EditorApplication.timeSinceStartup,
                changedAssets = changedAssets
            });
            Trim();
        }

        internal static List<LogBurst> GetLogBursts()
        {
            Trim();
            return Logs
                .GroupBy(log => log.type + "\n" + log.message)
                .Select(group => new LogBurst
                {
                    message = group.First().message,
                    type = group.First().type,
                    count = group.Count()
                })
                .Where(group => group.count >= 5)
                .OrderByDescending(group => group.count)
                .Take(20)
                .ToList();
        }

        internal static void GetRefreshStats(out int events, out int changedAssets)
        {
            Trim();
            events = Refreshes.Count;
            changedAssets = Refreshes.Sum(refresh => refresh.changedAssets);
        }

        private static void Trim()
        {
            double threshold = EditorApplication.timeSinceStartup - 60d;
            while (Logs.Count > 0 && Logs.Peek().time < threshold)
                Logs.Dequeue();
            while (Refreshes.Count > 0 && Refreshes.Peek().time < threshold)
                Refreshes.Dequeue();
        }

        private static string NormalizeLog(string condition)
        {
            string line = condition.Replace("\r", "").Split('\n')[0].Trim();
            return line.Length > 300 ? line.Substring(0, 300) + "..." : line;
        }
    }

    internal sealed class ProjectHealthAssetMonitor : AssetPostprocessor
    {
        private static void OnPostprocessAllAssets(
            string[] importedAssets,
            string[] deletedAssets,
            string[] movedAssets,
            string[] movedFromAssetPaths)
        {
            int changed = (importedAssets?.Length ?? 0) +
                          (deletedAssets?.Length ?? 0) +
                          (movedAssets?.Length ?? 0);
            ProjectHealthSessionMonitor.RecordRefresh(changed);
        }
    }

    public sealed class ProjectHealthScannerWindow : EditorWindow
    {
        private const long MB = 1024L * 1024L;
        private const string GeneratedResourcesMarker = "/GeneratedResources/";

        private Vector2 _scroll;
        private HealthReport _report;
        private string _filter = "";
        private bool _showInfo = true;
        private bool _showWarnings = true;
        private bool _showCritical = true;
        private int _usageMode;
        private int _audienceMode;
        private int _languageMode;
        private int _sortMode;
        private readonly Dictionary<string, bool> _causeFoldouts = new Dictionary<string, bool>();
        private readonly HashSet<string> _selectedDeletePaths =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private GUIStyle _cardStyle;
        private GUIStyle _titleStyle;
        private GUIStyle _subtitleStyle;
        private GUIStyle _sectionStyle;

        private sealed class FindingGroup
        {
            public string key;
            public string category;
            public string title;
            public string recommendation;
            public HealthSeverity severity;
            public List<HealthFinding> findings;
        }

        [MenuItem("Tools/MiM/Project Health Scanner")]
        public static void Open()
        {
            GetWindow<ProjectHealthScannerWindow>("Project Health");
        }

        [MenuItem("Tools/MiM/Project Health Scanner/Scan Project")]
        public static void ScanFromMenu()
        {
            var window = GetWindow<ProjectHealthScannerWindow>("Project Health");
            window.RunScan();
        }

        private void OnEnable()
        {
            _audienceMode = 0;
        }

        private void OnGUI()
        {
            EnsureStyles();
            EditorGUILayout.Space(8);

            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField("Project Health Scanner", _titleStyle);
                GUILayout.FlexibleSpace();
                _languageMode = GUILayout.Toolbar(
                    _languageMode,
                    new[] { "日本語", "English" },
                    GUILayout.Width(150));
            }
            EditorGUILayout.LabelField(
                T("不要なPackageとUnityが重くなる原因を、やること順に整理します。",
                  "Find unused packages and Unity performance issues, organized by action."),
                _subtitleStyle);
            EditorGUILayout.Space(6);

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(T("スキャン", "Scan"), GUILayout.Height(30)))
                    RunScan();

                using (new EditorGUI.DisabledScope(_report == null))
                {
                    if (_audienceMode == 1 && GUILayout.Button(T("JSON出力", "Export JSON"), GUILayout.Height(30)))
                        ExportJson();
                }
            }

            if (_report == null)
            {
                EditorGUILayout.HelpBox(
                    T("「スキャン」を押すと、削除候補と改善候補を分けて表示します。",
                      "Press Scan to separate delete candidates from improvement candidates."),
                    MessageType.Info);
                return;
            }

            EditorGUILayout.Space(8);
            /*
            _audienceMode = GUILayout.Toolbar(_audienceMode,
                new[] { T("かんたん", "Simple"), T("開発者向け", "Developer") });
            */
            _usageMode = GUILayout.Toolbar(_usageMode,
                new[]
                {
                    T("削除候補", "Delete candidates"),
                    T("改善候補", "Improvements"),
                    T("すべて", "All")
                });

            _sortMode = GUILayout.Toolbar(_sortMode,
                new[]
                {
                    T("優先度順", "Priority"),
                    T("サイズ順", "Size")
                });
            EditorGUILayout.LabelField(
                _sortMode == 0
                    ? T("優先度順: 重要度 → 削除候補 → 影響が大きい項目 → サイズ",
                        "Priority: severity → delete candidates → impact → size")
                    : T("サイズ順: 容量が大きい項目を上に表示",
                        "Size: largest items first"),
                _subtitleStyle);

            var groups = BuildGroups();
            var visibleFindings = GetBaseVisibleFindings().ToArray();
            int deleteCandidateCount = visibleFindings.Count(IsDeletableFinding);
            int improvementCauseCount = visibleFindings
                .Where(f => !IsCleanupFinding(f) && f.severity != HealthSeverity.Info)
                .Select(f => f.category + "\n" + f.title)
                .Distinct()
                .Count();
            EditorGUILayout.LabelField(
                T($"削除候補 {deleteCandidateCount}フォルダ　改善候補 {improvementCauseCount}種類",
                  $"{deleteCandidateCount} folders to review   {improvementCauseCount} improvement types"),
                _sectionStyle);

            int criticalCount;
            int warningCount;
            int infoCount;
            GetVisibleSeverityCounts(out criticalCount, out warningCount, out infoCount);
            using (new EditorGUILayout.HorizontalScope())
            {
                _showCritical = DrawSeverityToggle(
                    _showCritical, T("重要", "Critical"), criticalCount, SoftSeverityColor(HealthSeverity.Critical));
                _showWarnings = DrawSeverityToggle(
                    _showWarnings, T("注意", "Warning"), warningCount, SoftSeverityColor(HealthSeverity.Warning));
                _showInfo = DrawSeverityToggle(
                    _showInfo, T("参考", "Info"), infoCount, SoftSeverityColor(HealthSeverity.Info));
                _filter = EditorGUILayout.TextField(_filter, GUI.skin.FindStyle("ToolbarSearchTextField"));
            }

            if (_usageMode == 0)
                DrawDeleteToolbar();

            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            if (groups.Count == 0)
                EditorGUILayout.HelpBox(
                    _usageMode == 0
                        ? T("削除候補は見つかりませんでした。",
                            "No delete candidates were found.")
                        : T("この条件に一致する問題は見つかりませんでした。",
                            "No issues matched this filter."),
                    MessageType.Info);
            foreach (var group in groups)
                DrawFindingGroup(group);
            EditorGUILayout.EndScrollView();
        }

        private List<FindingGroup> BuildGroups()
        {
            var groups = GetBaseVisibleFindings()
                .Where(f => (f.severity == HealthSeverity.Critical && _showCritical) ||
                            (f.severity == HealthSeverity.Warning && _showWarnings) ||
                            (f.severity == HealthSeverity.Info && _showInfo))
                .GroupBy(GetFindingGroupKey)
                .Select(g => new FindingGroup
                {
                    key = g.Key,
                    category = g.First().category,
                    title = g.First().title,
                    recommendation = g.First().recommendation,
                    severity = g.Max(x => x.severity),
                    findings = SortFindings(g)
                })
                .ToList();

            if (_sortMode == 1)
            {
                return groups
                    .OrderByDescending(GetGroupSize)
                    .ThenByDescending(g => g.severity)
                    .ThenBy(g => GetGroupPriority(g))
                    .ThenBy(g => g.category)
                    .ThenBy(g => g.title)
                    .ToList();
            }

            return groups
                .OrderByDescending(g => g.severity)
                .ThenBy(g => GetGroupPriority(g))
                .ThenByDescending(GetGroupSize)
                .ThenBy(g => g.category)
                .ThenBy(g => g.title)
                .ToList();
        }

        private List<HealthFinding> SortFindings(IEnumerable<HealthFinding> findings)
        {
            if (_sortMode == 1)
            {
                return findings
                    .OrderByDescending(GetFindingSize)
                    .ThenBy(x => GetDisplayFolder(x))
                    .ThenBy(x => x.assetPath)
                    .ThenBy(x => x.detail)
                    .ToList();
            }

            return findings
                .OrderBy(GetFindingPriority)
                .ThenByDescending(GetFindingSize)
                .ThenBy(x => GetDisplayFolder(x))
                .ThenBy(x => x.assetPath)
                .ThenBy(x => x.detail)
                .ToList();
        }

        private static long GetGroupSize(FindingGroup group)
        {
            return group == null || group.findings == null
                ? 0
                : group.findings.Select(GetFindingSize).DefaultIfEmpty(0).Max();
        }

        private static long GetFindingSize(HealthFinding finding)
        {
            if (finding == null)
                return 0;
            if (finding.sizeBytes > 0)
                return finding.sizeBytes;
            return string.IsNullOrEmpty(finding.assetPath) ? 0 : GetAssetBytes(finding.assetPath);
        }

        private static int GetGroupPriority(FindingGroup group)
        {
            return group == null || group.findings == null
                ? 1000
                : group.findings.Select(GetFindingPriority).DefaultIfEmpty(1000).Min();
        }

        private static int GetFindingPriority(HealthFinding finding)
        {
            if (finding == null)
                return 1000;

            int score = 0;

            if (!IsCleanupFinding(finding))
                score += 100;

            if (finding.title.IndexOf("Scene内で使用中", StringComparison.OrdinalIgnoreCase) >= 0)
                score -= 40;

            if (finding.category == "Unused / Animator" || finding.category == "Animator")
                score -= 30;

            if (finding.category == "Texture")
                score -= 25;

            if (finding.category == "Asset Size" || finding.category == "Source Asset")
                score -= 20;

            long size = GetFindingSize(finding);
            if (size >= 100 * MB)
                score -= 15;
            else if (size >= 50 * MB)
                score -= 10;
            else if (size >= 10 * MB)
                score -= 5;

            return score;
        }

        private static string GetFindingGroupKey(HealthFinding finding)
        {
            if (finding.category == "Unused / Animator")
                return finding.category;

            return finding.category + "\n" + finding.title + "\n" + finding.recommendation;
        }

        private IEnumerable<HealthFinding> GetBaseVisibleFindings()
        {
            return _report.findings
                .Where(f => !IsMinimumModeHidden(f))
                .Where(f => _usageMode == 2 ||
                            (_usageMode == 0 && IsCleanupFinding(f)) ||
                            (_usageMode == 1 && !IsCleanupFinding(f)))
                .Where(f => _audienceMode == 1 ||
                            f.severity != HealthSeverity.Info ||
                            !IsDeveloperOnlyInfo(f))
                .Where(f => string.IsNullOrWhiteSpace(_filter) ||
                            (f.category + " " + f.title + " " + f.detail + " " +
                             f.recommendation + " " + f.assetPath)
                            .IndexOf(_filter, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private static bool IsMinimumModeHidden(HealthFinding finding)
        {
            if (finding == null)
                return true;

            switch (finding.category)
            {
                case "Components":
                case "Preview":
                case "Scene":
                case "Rendering":
                case "Scene Memory":
                case "Physics":
                    return true;
                default:
                    return false;
            }
        }

        private void GetVisibleSeverityCounts(out int critical, out int warning, out int info)
        {
            var findings = GetBaseVisibleFindings().ToArray();
            critical = findings.Count(f => f.severity == HealthSeverity.Critical);
            warning = findings.Count(f => f.severity == HealthSeverity.Warning);
            info = findings.Count(f => f.severity == HealthSeverity.Info);
        }

        private static bool IsDeletableFinding(HealthFinding finding)
        {
            return finding != null &&
                   IsCleanupFinding(finding) &&
                   !string.IsNullOrEmpty(finding.assetPath) &&
                   (AssetDatabase.IsValidFolder(finding.assetPath) ||
                    AssetDatabase.LoadMainAssetAtPath(finding.assetPath) != null);
        }

        private static bool IsCleanupFinding(HealthFinding finding)
        {
            return finding.category.StartsWith("Unused", StringComparison.Ordinal);
        }

        private static bool IsDeveloperOnlyInfo(HealthFinding finding)
        {
            return finding.category == "Summary" ||
                   finding.category == "System Memory" ||
                   finding.category == "Asset Refresh" ||
                   finding.category == "Editor Extensions" ||
                   finding.title.Contains("現在のSceneView設定") ||
                   finding.title.Contains("集計") ||
                   finding.title.Contains("概算") ||
                   finding.title.Contains("候補");
        }

        private void DrawFindingGroup(FindingGroup group)
        {
            Rect cardRect = EditorGUILayout.BeginVertical(_cardStyle);
            bool expanded = GetFoldout(_causeFoldouts, group.key, false);
            string count = T($"  {group.findings.Count}件", $"  {group.findings.Count} items");
            expanded = EditorGUILayout.Foldout(
                expanded,
                _audienceMode == 0
                    ? $"{SeverityLabel(group.severity)}  {GetSimpleTitle(group)}{count}"
                    : $"{SeverityLabel(group.severity)}  [{GetLocalizedCategory(group.category)}] " +
                      $"{GetLocalizedTitle(group)}{count}",
                true,
                EditorStyles.foldoutHeader);
            _causeFoldouts[group.key] = expanded;

            EditorGUILayout.LabelField(BuildGroupPreview(group), _subtitleStyle);

            if (expanded)
            {
                string action = GetLocalizedRecommendation(group);
                if (!string.IsNullOrEmpty(action))
                    DrawActionBox(action);

                var folderGroups = group.findings
                    .GroupBy(GetDisplayFolder)
                    .OrderBy(g => g.Key)
                    .ToArray();

                foreach (var folderGroup in folderGroups)
                {
                    string folderPreview = BuildFolderPreview(folderGroup);
                    var deletableItems = folderGroup.Where(IsDeletableFinding).ToArray();
                    HealthFinding singleDeletable =
                        deletableItems.Length == 1 ? deletableItems[0] : null;

                    using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                    {
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            if (singleDeletable != null)
                                DrawDeleteCheckbox(singleDeletable.assetPath);

                            EditorGUILayout.LabelField(
                                _audienceMode == 0
                                    ? GetSimpleGroupLocation(folderGroup)
                                    : folderGroup.Key,
                                EditorStyles.boldLabel);
                            GUILayout.FlexibleSpace();
                            EditorGUILayout.LabelField(
                                T($"{folderGroup.Count()}件", $"{folderGroup.Count()} items"),
                                _subtitleStyle,
                                GUILayout.Width(70));
                            if (folderGroup.Any(f => !string.IsNullOrEmpty(f.assetPath)) &&
                                GUILayout.Button(T("場所", "Folder"), GUILayout.Width(52)))
                                PingFolder(folderGroup.First(f => !string.IsNullOrEmpty(f.assetPath)).assetPath);
                        }

                        EditorGUILayout.LabelField(
                            T("場所: ", "Path: ") + GetDisplayPath(folderGroup),
                            _subtitleStyle);
                        EditorGUILayout.LabelField(folderPreview, _subtitleStyle);

                        if (deletableItems.Length > 1)
                        {
                            foreach (var item in deletableItems)
                                DrawDeletableItemRow(item);
                        }
                        else if (_audienceMode == 0)
                        {
                            string summary = GetSimpleDetail(folderGroup.First());
                            if (!string.IsNullOrEmpty(summary))
                                EditorGUILayout.LabelField(summary, EditorStyles.wordWrappedLabel);
                        }
                        else
                            foreach (var finding in folderGroup)
                                DrawFindingRow(finding);
                    }
                }
            }
            EditorGUILayout.EndVertical();

            if (Event.current.type == EventType.Repaint)
            {
                var line = new Rect(cardRect.x, cardRect.y + 2, 4, Mathf.Max(0, cardRect.height - 4));
                EditorGUI.DrawRect(line, SeverityColor(group.severity));
            }
        }

        private string GetSimpleTitle(FindingGroup group)
        {
            if (group.category == "Unused / Animator")
                return T("削除候補のAnimator", "Animator delete candidates");
            if (group.category.StartsWith("Unused", StringComparison.Ordinal))
                return T("削除候補のPackage / Asset", "Package / asset delete candidates");
            if (group.category == "Integrity")
                return group.title.Contains("Prefab")
                    ? T("壊れたPrefabがあります", "A prefab reference is broken")
                    : T("Missing Scriptがあります", "A script is missing");
            if (group.category == "System Memory")
                return T("メモリ不足の可能性", "Possible RAM shortage");
            if (group.category == "GPU Memory")
                return T("VRAM不足の可能性", "Possible VRAM shortage");
            if (group.category == "Console")
                return T("同じエラーや警告が繰り返されています", "The same Console message is repeating");
            if (group.category == "Asset Refresh")
                return T("Assetの再読み込みが繰り返されています", "Assets are being refreshed repeatedly");
            if (group.category == "SceneView")
                return T("Scene画面の表示設定が重い", "Scene view settings are expensive");
            if (group.category == "Editor Extensions")
                return T("常に動いているEditorツールがあります", "An editor tool may be running continuously");
            return GetLocalizedTitle(group);
        }

        private string GetSimpleFolderName(string folder)
        {
            if (string.Equals(folder, "Assets", StringComparison.OrdinalIgnoreCase))
                return T("Assets直下", "Assets root");
            if (folder.StartsWith("Assets/", StringComparison.Ordinal))
                return Path.GetFileName(folder);
            return folder;
        }

        private string GetSimpleGroupLocation(IGrouping<string, HealthFinding> folderGroup)
        {
            if (!string.Equals(folderGroup.Key, "Assets", StringComparison.OrdinalIgnoreCase))
                return GetSimpleFolderName(folderGroup.Key);

            var names = folderGroup
                .Select(f => !string.IsNullOrEmpty(f.assetPath)
                    ? Path.GetFileName(f.assetPath.TrimEnd('/', '\\'))
                    : "")
                .Where(name => !string.IsNullOrWhiteSpace(name))
                .Distinct()
                .Take(2)
                .ToArray();
            return names.Length > 0
                ? string.Join(" / ", names)
                : T("Assets直下", "Assets root");
        }

        private static string GetDisplayPath(IGrouping<string, HealthFinding> folderGroup)
        {
            var paths = folderGroup
                .Select(f => f.assetPath)
                .Where(path => !string.IsNullOrEmpty(path))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Take(2)
                .ToArray();
            if (paths.Length == 0)
                return folderGroup.Key;
            if (paths.Length == 1)
                return paths[0];
            return string.Join("  |  ", paths);
        }

        private void DrawActionBox(string action)
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField(T("やること", "What to do"), EditorStyles.boldLabel);
                EditorGUILayout.LabelField(action, EditorStyles.wordWrappedLabel);
            }
        }

        private bool DrawSeverityToggle(
            bool value,
            string label,
            int count,
            Color background)
        {
            Color previous = GUI.backgroundColor;
            GUI.backgroundColor = value ? background : Color.white;
            bool next = GUILayout.Toggle(
                value,
                $"{label}  {count}",
                EditorStyles.miniButton,
                GUILayout.MinWidth(90));
            GUI.backgroundColor = previous;
            return next;
        }

        private void DrawDeleteCheckbox(string path)
        {
            bool selected = _selectedDeletePaths.Contains(path);
            bool next = EditorGUILayout.Toggle(selected, GUILayout.Width(18));
            if (next == selected)
                return;
            if (next) _selectedDeletePaths.Add(path);
            else _selectedDeletePaths.Remove(path);
        }

        private void DrawDeletableItemRow(HealthFinding finding)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                DrawDeleteCheckbox(finding.assetPath);
                EditorGUILayout.LabelField(
                    Path.GetFileName(finding.assetPath.TrimEnd('/', '\\')),
                    EditorStyles.label,
                    GUILayout.MinWidth(130));
                GUILayout.FlexibleSpace();
                EditorGUILayout.LabelField(
                    finding.assetPath,
                    _subtitleStyle,
                    GUILayout.MaxWidth(420));
                if (GUILayout.Button(T("場所", "Ping"), GUILayout.Width(52)))
                {
                    var asset = AssetDatabase.LoadMainAssetAtPath(finding.assetPath);
                    if (asset != null)
                    {
                        EditorGUIUtility.PingObject(asset);
                        Selection.activeObject = asset;
                    }
                }
            }
        }

        private void DrawDeleteToolbar()
        {
            var available = _report.findings
                .Where(IsDeletableFinding)
                .Select(f => f.assetPath)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();

            _selectedDeletePaths.RemoveWhere(path => !available.Contains(
                path, StringComparer.OrdinalIgnoreCase));

            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField(
                    T($"削除する項目を選択: {_selectedDeletePaths.Count}/{available.Length}",
                      $"Selected items: {_selectedDeletePaths.Count}/{available.Length}"),
                    EditorStyles.boldLabel);
                GUILayout.FlexibleSpace();

                if (GUILayout.Button(T("すべて選択", "Select all"), GUILayout.Width(82)))
                    foreach (string path in available)
                        _selectedDeletePaths.Add(path);
                if (GUILayout.Button(T("選択解除", "Clear"), GUILayout.Width(70)))
                    _selectedDeletePaths.Clear();

                using (new EditorGUI.DisabledScope(_selectedDeletePaths.Count == 0))
                {
                    Color previous = GUI.backgroundColor;
                    GUI.backgroundColor = new Color(1f, 0.72f, 0.66f);
                    if (GUILayout.Button(
                            T($"選択した{_selectedDeletePaths.Count}項目を削除",
                              $"Delete {_selectedDeletePaths.Count} selected"),
                            GUILayout.Width(190)))
                        DeleteSelectedPackages();
                    GUI.backgroundColor = previous;
                }
            }
        }

        private void DeleteSelectedPackages()
        {
            string[] paths = _selectedDeletePaths
                .Where(path => AssetDatabase.IsValidFolder(path) ||
                               AssetDatabase.LoadMainAssetAtPath(path) != null)
                .OrderBy(path => path)
                .ToArray();
            if (paths.Length == 0)
                return;

            string preview = string.Join("\n", paths.Take(12));
            if (paths.Length > 12)
                preview += T($"\nほか{paths.Length - 12}項目",
                             $"\n+{paths.Length - 12} more items");

            bool confirmed = EditorUtility.DisplayDialog(
                T("選択した削除候補を削除", "Delete selected candidates"),
                T(
                    $"次の{paths.Length}項目をOSのごみ箱へ移動します。\n\n{preview}\n\n" +
                    "Project内の参照は見つかっていませんが、保管目的や外部ツールから使う場合はキャンセルしてください。",
                    $"Move these {paths.Length} items to the operating system recycle bin:\n\n{preview}\n\n" +
                    "No project reference was found. Cancel if you keep them for storage or use them from an external tool."),
                T("ごみ箱へ移動", "Move to trash"),
                T("キャンセル", "Cancel"));
            if (!confirmed)
                return;

            var failed = new List<string>();
            AssetDatabase.StartAssetEditing();
            try
            {
                foreach (string path in paths)
                {
                    if (!AssetDatabase.MoveAssetToTrash(path))
                        failed.Add(path);
                }
            }
            finally
            {
                AssetDatabase.StopAssetEditing();
                AssetDatabase.Refresh();
            }

            _selectedDeletePaths.Clear();
            if (failed.Count > 0)
                EditorUtility.DisplayDialog(
                    T("一部削除できませんでした", "Some folders could not be deleted"),
                    string.Join("\n", failed),
                    "OK");
            RunScan();
        }

        private void DrawSimpleFolderContent(IGrouping<string, HealthFinding> folderGroup)
        {
            var findings = folderGroup.ToArray();
            if (findings.Length == 1)
            {
                var finding = findings[0];
                string summary = GetSimpleDetail(finding);
                if (!string.IsNullOrEmpty(summary))
                    EditorGUILayout.LabelField(summary, EditorStyles.wordWrappedLabel);

                if (finding.instanceId != 0 && string.IsNullOrEmpty(finding.assetPath))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.FlexibleSpace();
                        DrawFindingButtons(finding);
                    }
                }
                return;
            }

            EditorGUILayout.LabelField(
                T($"対象が{findings.Length}件あります。上の概要で内容を確認できます。",
                  $"{findings.Length} items. See the summary above."),
                EditorStyles.wordWrappedLabel);
        }

        private string GetSimpleDetail(HealthFinding finding)
        {
            if (finding.category.StartsWith("Unused", StringComparison.Ordinal))
                return T("このPackage内のAssetは、他のPackageやSceneから使われていません。",
                         "No asset in this package is referenced by another package or scene.");
            if (finding.category == "Integrity")
                return finding.detail;
            if (finding.category == "Console")
                return T("同じ処理が何度も失敗し、Unityを重くしている可能性があります。",
                         "The same operation may be failing repeatedly and slowing down Unity.");
            if (finding.category == "Asset Refresh")
                return T("ファイルの読み直しが繰り返され、操作が止まりやすくなっています。",
                         "Unity is repeatedly reloading files, which can interrupt editor input.");
            if (finding.category == "Editor Extensions")
                return T("Unityを操作していない時も動く可能性があります。",
                         "This tool may run even while the editor is idle.");
            return GetLocalizedDetail(finding);
        }

        private void DrawFindingRow(HealthFinding finding)
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                string label = !string.IsNullOrEmpty(finding.assetPath)
                    ? Path.GetFileName(finding.assetPath)
                    : finding.detail;
                EditorGUILayout.LabelField(label, EditorStyles.boldLabel);

                if (!string.IsNullOrEmpty(finding.assetPath) &&
                    finding.detail.IndexOf(finding.assetPath, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    string localizedDetail = GetLocalizedDetail(finding);
                    string compactDetail = localizedDetail.Replace(finding.assetPath, "").Trim(' ', ':');
                    if (!string.IsNullOrEmpty(compactDetail))
                        EditorGUILayout.LabelField(compactDetail, EditorStyles.wordWrappedMiniLabel);
                }
                else if (!string.IsNullOrEmpty(finding.detail) && finding.detail != label)
                {
                    EditorGUILayout.LabelField(GetLocalizedDetail(finding), EditorStyles.wordWrappedMiniLabel);
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.FlexibleSpace();
                    DrawFindingButtons(finding);
                }
            }
        }

        private void DrawFindingButtons(HealthFinding finding)
        {
            if (!string.IsNullOrEmpty(finding.assetPath) &&
                GUILayout.Button(T("表示", "Ping"), GUILayout.Width(52)))
            {
                var asset = AssetDatabase.LoadMainAssetAtPath(finding.assetPath);
                if (asset != null)
                {
                    EditorGUIUtility.PingObject(asset);
                    Selection.activeObject = asset;
                }
            }

            if (finding.instanceId != 0 && GUILayout.Button(T("選択", "Select"), GUILayout.Width(52)))
            {
                var obj = EditorUtility.InstanceIDToObject(finding.instanceId);
                if (obj != null)
                    Selection.activeObject = obj;
            }

        }

        private string BuildGroupPreview(FindingGroup group)
        {
            var folders = group.findings
                .Select(GetDisplayFolder)
                .Distinct()
                .Take(3)
                .Select(GetSimpleFolderName)
                .ToArray();
            string names = string.Join("  •  ", folders);
            int folderCount = group.findings.Select(GetDisplayFolder).Distinct().Count();
            string suffix = folderCount > folders.Length
                ? T($" ほか{folderCount - folders.Length}か所",
                    $" +{folderCount - folders.Length} more")
                : "";
            return string.IsNullOrEmpty(names)
                ? T("詳細を開いて確認", "Open for details")
                : names + suffix;
        }

        private string BuildFolderPreview(IGrouping<string, HealthFinding> folderGroup)
        {
            var single = folderGroup.Take(2).ToArray();
            if (single.Length == 1 &&
                !string.IsNullOrEmpty(single[0].assetPath) &&
                AssetDatabase.IsValidFolder(single[0].assetPath))
            {
                string packageSummary = single[0].detail
                    .Replace(single[0].assetPath, "")
                    .Trim(' ', ':');
                if (!string.IsNullOrEmpty(packageSummary))
                    return packageSummary;
            }

            var names = folderGroup
                .Select(f => !string.IsNullOrEmpty(f.assetPath)
                    ? Path.GetFileName(f.assetPath.TrimEnd('/', '\\'))
                    : GetShortObjectName(f.detail))
                .Where(name => !string.IsNullOrWhiteSpace(name))
                .Distinct()
                .Take(4)
                .ToArray();

            int total = folderGroup.Count();
            string preview = string.Join("  •  ", names);
            if (total > names.Length)
                preview += T($"  ほか{total - names.Length}件", $"  +{total - names.Length} more");
            return string.IsNullOrEmpty(preview)
                ? T("内容は詳細を開いて確認できます。", "Open details to inspect the items.")
                : preview;
        }

        private static string GetShortObjectName(string detail)
        {
            if (string.IsNullOrWhiteSpace(detail))
                return "";
            string first = detail.Replace("\r", "").Split('\n')[0];
            int colon = first.IndexOf(':');
            return colon > 0 ? first.Substring(0, colon) : first;
        }

        private string GetLocalizedCategory(string category)
        {
            if (_languageMode == 0)
                return category;

            if (category.StartsWith("Unused", StringComparison.Ordinal)) return "Unused";
            switch (category)
            {
                case "Integrity": return "Broken references";
                case "System Memory": return "RAM";
                case "GPU Memory": return "VRAM";
                case "Console": return "Console";
                case "Asset Refresh": return "Asset refresh";
                case "SceneView": return "Scene view";
                case "Editor Extensions": return "Editor extensions";
                case "Animator": return "Animator";
                case "Rendering": return "Rendering";
                case "Scene Memory": return "Scene memory";
                case "Scene": return "Scene";
                case "Project": return "Project";
                case "Texture": return "Texture";
                case "Source Asset": return "Source assets";
                case "Compilation": return "Compilation";
                case "Storage": return "Storage";
                case "Generated Files": return "Generated files";
                case "Physics": return "Physics";
                case "Audio": return "Audio";
                case "Tool Data": return "Tool data";
                case "Preview": return "Preview";
                case "Settings": return "Settings";
                case "Packages": return "Packages";
                case "Asset Database": return "Asset database";
                case "Components": return "Components";
                default: return category;
            }
        }

        private string GetLocalizedTitle(FindingGroup group)
        {
            if (_languageMode == 0)
                return group.title;
            return GetSimpleTitleEnglish(group);
        }

        private static string GetSimpleTitleEnglish(FindingGroup group)
        {
            if (group.category == "Unused / Animator") return "Animator delete candidates";
            if (group.category.StartsWith("Unused", StringComparison.Ordinal)) return "Package / asset delete candidates";
            if (group.category == "Integrity")
                return group.title.Contains("Prefab") ? "Broken prefab reference" : "Missing script";
            if (group.category == "System Memory") return "High RAM usage";
            if (group.category == "GPU Memory") return "High VRAM usage";
            if (group.category == "Console") return "Repeated Console message";
            if (group.category == "Asset Refresh") return "Frequent asset refresh";
            if (group.category == "SceneView") return "Expensive Scene view settings";
            if (group.category == "Editor Extensions") return "Editor code that may run continuously";
            if (group.category == "Animator") return "Large Animator Controller";
            if (group.category == "Rendering") return "High rendering workload";
            if (group.category == "Scene Memory") return "Large inactive scene content";
            if (group.category == "Texture") return "Expensive texture setting";
            if (group.category == "Source Asset") return "Large source image";
            if (group.category == "Compilation") return "Slow script compilation structure";
            if (group.category == "Storage") return "Slow project storage";
            if (group.category == "Physics") return "High physics workload";
            if (group.category == "Audio") return "Expensive audio import setting";
            if (group.category == "Tool Data") return "Broken or duplicated tool data";
            if (group.category == "Preview") return "Saved preview objects";
            return group.title;
        }

        private string GetLocalizedRecommendation(FindingGroup group)
        {
            if (_languageMode == 0)
                return group.recommendation;

            if (group.category.StartsWith("Unused", StringComparison.Ordinal))
            {
                if (group.category == "Unused / Animator")
                    return "This Animator Controller is not referenced by scenes, prefabs, or other assets. Delete it only if you do not need it as a backup.";
                return "If you do not need this package for future work, remove the whole folder. Keep it if it is only being stored here.";
            }
            switch (group.category)
            {
                case "Integrity":
                    return group.title.Contains("Prefab")
                        ? "Reimport the original prefab. If the instance is intentionally detached, unpack or remove it."
                        : "Restore the missing package, or remove the missing component if it is no longer needed.";
                case "System Memory":
                    return "Close other applications and split large scenes or avatar collections into separate scenes.";
                case "GPU Memory":
                    return "Hide avatars you are not editing and reduce 8K textures, render textures, shadows, and post-processing.";
                case "Console":
                    return "Open the Console stack trace and stop the source from logging every Update, OnGUI, or OnValidate.";
                case "Asset Refresh":
                    return "Check generators, AssetPostprocessors, cloud sync, or external tools that keep rewriting project files.";
                case "SceneView":
                    return "Disable Lighting, Effects, Particles, or reduce the Scene view size while editing.";
                case "Editor Extensions":
                    return "Remove unused editor tools. For your own code, run only when selected or add an update interval.";
                case "Animator":
                    return "Remove duplicated generated controllers, unnecessary layers, all-state transitions, and oversized blend trees.";
                case "Rendering":
                    return "Hide or move avatars you are not editing to another scene.";
                case "Scene Memory":
                    return "No change is required for rendering. Split the scene only if loading, saving, or memory usage is slow.";
                case "Texture":
                    return "Disable Read/Write unless scripts need pixel access. Keep normal 4K textures as-is.";
                case "Source Asset":
                    return "Keep editable source files outside Unity and import only the exported image when possible.";
                case "Compilation":
                    return "Split your own runtime and editor code into assembly definitions. Do not modify purchased assets unnecessarily.";
                case "Storage":
                    return "Move the project to a local SSD outside cloud-synced folders.";
                case "Physics":
                    return "Remove unused colliders and rigidbodies, and stop editor-time simulation when not needed.";
                case "Audio":
                    return "Use Streaming for long audio and Compressed In Memory for suitable short clips.";
                case "Tool Data":
                    return "Remove only broken or duplicated tool entries after confirming the target avatar.";
                case "Preview":
                    return "Use the tool's official cleanup command before deleting preview objects manually.";
                default:
                    return "Review the listed items and change only what is no longer needed.";
            }
        }

        private string GetLocalizedDetail(HealthFinding finding)
        {
            if (_languageMode == 0)
                return finding.detail;
            if (finding.category.StartsWith("Unused", StringComparison.Ordinal))
            {
                if (finding.category == "Unused / Animator")
                    return "No scene, prefab, or asset reference was found for this Animator Controller.";
                return "No external reference was found for this package.";
            }
            if (finding.category == "Integrity")
                return "Affected object: " + finding.detail;
            return finding.detail;
        }

        private string T(string japanese, string english)
        {
            return _languageMode == 0 ? japanese : english;
        }

        private void EnsureStyles()
        {
            if (_cardStyle != null)
                return;

            _cardStyle = new GUIStyle(EditorStyles.helpBox)
            {
                margin = new RectOffset(4, 4, 6, 6),
                padding = new RectOffset(12, 12, 8, 10)
            };
            _titleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 17,
                fixedHeight = 22
            };
            _subtitleStyle = new GUIStyle(EditorStyles.wordWrappedMiniLabel)
            {
                fontSize = 11,
                normal = { textColor = EditorGUIUtility.isProSkin
                    ? new Color(0.72f, 0.74f, 0.78f)
                    : new Color(0.30f, 0.32f, 0.36f) }
            };
            _sectionStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 12,
                margin = new RectOffset(2, 2, 8, 4)
            };
        }

        private static Color SeverityColor(HealthSeverity severity)
        {
            switch (severity)
            {
                case HealthSeverity.Critical: return new Color(0.90f, 0.35f, 0.32f, 0.9f);
                case HealthSeverity.Warning: return new Color(0.95f, 0.67f, 0.25f, 0.9f);
                default: return new Color(0.35f, 0.62f, 0.88f, 0.8f);
            }
        }

        private static Color SoftSeverityColor(HealthSeverity severity)
        {
            return SeverityColor(severity);
        }

        private static string GetDisplayFolder(HealthFinding finding)
        {
            if (!string.IsNullOrEmpty(finding.assetPath))
            {
                string normalized = finding.assetPath.Replace('\\', '/');
                if (AssetDatabase.IsValidFolder(normalized))
                    return normalized;
                string directory = Path.GetDirectoryName(normalized);
                return string.IsNullOrEmpty(directory) ? "Project Root" : directory.Replace('\\', '/');
            }

            if (finding.instanceId != 0)
            {
                var obj = EditorUtility.InstanceIDToObject(finding.instanceId);
                if (obj is Component component && component.gameObject.scene.IsValid())
                    return "Scene: " + component.gameObject.scene.name;
                if (obj is GameObject gameObject && gameObject.scene.IsValid())
                    return "Scene: " + gameObject.scene.name;
            }

            return "Project / Settings";
        }

        private static bool GetFoldout(Dictionary<string, bool> states, string key, bool defaultValue)
        {
            return states.TryGetValue(key, out bool value) ? value : defaultValue;
        }

        private static string SeverityLabel(HealthSeverity severity)
        {
            return severity == HealthSeverity.Critical ? "重要" :
                   severity == HealthSeverity.Warning ? "注意" : "情報";
        }

        private static void PingFolder(string assetPath)
        {
            string normalized = assetPath.Replace('\\', '/');
            string directory = AssetDatabase.IsValidFolder(normalized)
                ? normalized
                : Path.GetDirectoryName(normalized)?.Replace('\\', '/');
            if (string.IsNullOrEmpty(directory))
                return;

            var folder = AssetDatabase.LoadAssetAtPath<Object>(directory);
            if (folder != null)
            {
                EditorGUIUtility.PingObject(folder);
                Selection.activeObject = folder;
            }
        }

        private void RunScan()
        {
            var stopwatch = Stopwatch.StartNew();
            _report = new HealthReport
            {
                unityVersion = Application.unityVersion,
                projectPath = Directory.GetParent(Application.dataPath)?.FullName ?? Application.dataPath,
                scannedAt = DateTime.Now.ToString("O")
            };

            try
            {
                ScanAssets(_report);
            }
            catch (Exception ex)
            {
                Add(_report, HealthSeverity.Critical, "Scanner", "スキャン中に例外",
                    ex.ToString(), "Consoleを確認してください。");
                Debug.LogException(ex);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
                stopwatch.Stop();
                _report.elapsedSeconds = stopwatch.Elapsed.TotalSeconds;
                _report.score = CalculateScore(_report.findings);
                Repaint();
            }
        }

        private static void ScanSystemResources(HealthReport report)
        {
            long reservedMemory = Profiler.GetTotalReservedMemoryLong();
            long allocatedMemory = Profiler.GetTotalAllocatedMemoryLong();
            long graphicsMemory = Profiler.GetAllocatedMemoryForGraphicsDriver();
            long systemMemory = Math.Max(1, SystemInfo.systemMemorySize) * MB;
            long vram = Math.Max(0, SystemInfo.graphicsMemorySize) * MB;

            double ramRatio = reservedMemory / (double)systemMemory;
            if (ramRatio >= 0.75)
                Add(report, HealthSeverity.Critical, "System Memory", "UnityのRAM予約量が非常に多い",
                    $"Unity Reserved {FormatBytes(reservedMemory)} / System RAM {FormatBytes(systemMemory)}",
                    "他アプリを閉じ、巨大Sceneや不要Assetを分離してください。再起動で解放されるEditorキャッシュもあります。");
            else if (ramRatio >= 0.5)
                Add(report, HealthSeverity.Warning, "System Memory", "UnityのRAM予約量が多い",
                    $"Unity Reserved {FormatBytes(reservedMemory)} / Allocated {FormatBytes(allocatedMemory)} / " +
                    $"System RAM {FormatBytes(systemMemory)}",
                    "複数アバター・巨大Texture・Read/Write・Preview Cloneを確認してください。");

            if (vram > 0)
            {
                double vramRatio = graphicsMemory / (double)vram;
                if (vramRatio >= 0.85)
                    Add(report, HealthSeverity.Critical, "GPU Memory", "推定VRAM使用量が上限付近",
                        $"Graphics Driver {FormatBytes(graphicsMemory)} / VRAM {FormatBytes(vram)}",
                        "SceneViewの同時表示、8K Texture、RenderTexture、Shadow、Post Processingを減らしてください。");
                else if (vramRatio >= 0.65)
                    Add(report, HealthSeverity.Warning, "GPU Memory", "推定VRAM使用量が多い",
                        $"Graphics Driver {FormatBytes(graphicsMemory)} / VRAM {FormatBytes(vram)}",
                        "SceneViewで非編集ルートを非表示にし、不要な高解像度Textureを減らしてください。");
            }

            Add(report, HealthSeverity.Info, "System Memory", "RAM・VRAMの概算",
                $"Unity Allocated {FormatBytes(allocatedMemory)} / Reserved {FormatBytes(reservedMemory)} / " +
                $"System RAM {FormatBytes(systemMemory)} / Graphics Driver {FormatBytes(graphicsMemory)} / " +
                $"VRAM {FormatBytes(vram)}",
                "Unity Profiler APIによる概算です。他アプリの使用量や共有GPUメモリは完全には含みません。");
        }

        private static void ScanSessionActivity(HealthReport report)
        {
            foreach (var burst in ProjectHealthSessionMonitor.GetLogBursts())
            {
                Add(report,
                    burst.count >= 30 ? HealthSeverity.Critical : HealthSeverity.Warning,
                    "Console", "同じConsoleログが連続発生",
                    $"直近60秒で{burst.count}回: {burst.message}",
                    "Stack Traceから発生元を特定し、毎Update/OnGUI/OnValidateで出力しないよう修正してください。");
            }

            ProjectHealthSessionMonitor.GetRefreshStats(out int refreshEvents, out int changedAssets);
            if (refreshEvents >= 12 || changedAssets >= 1000)
                Add(report,
                    refreshEvents >= 30 ? HealthSeverity.Critical : HealthSeverity.Warning,
                    "Asset Refresh", "Asset Refreshが頻発",
                    $"直近60秒: Refresh callback {refreshEvents}回 / 変更Asset {changedAssets:N0}件",
                    "自動生成ツール、AssetPostprocessor、外部同期ソフトがファイルを書き換え続けていないか確認してください。");
            else
                Add(report, HealthSeverity.Info, "Asset Refresh", "直近のAsset更新",
                    $"直近60秒: Refresh callback {refreshEvents}回 / 変更Asset {changedAssets:N0}件",
                    "Unity起動直後やPackage導入直後の一時的な更新は正常です。");
        }

        private static void ScanSceneView(HealthReport report)
        {
            var view = SceneView.lastActiveSceneView;
            if (view == null || view.camera == null)
                return;

            int width = view.camera.pixelWidth;
            int height = view.camera.pixelHeight;
            long pixels = (long)width * height;
            var enabledFeatures = new List<string>();

            if (view.sceneLighting)
                enabledFeatures.Add("Lighting");
            if (GetSceneViewState(view, "showImageEffects"))
                enabledFeatures.Add("Post Processing");
            if (GetSceneViewState(view, "showFog"))
                enabledFeatures.Add("Fog");
            if (GetSceneViewState(view, "showFlares"))
                enabledFeatures.Add("Flares");
            if (GetSceneViewState(view, "showParticleSystems"))
                enabledFeatures.Add("Particles");

            if (pixels >= 3840L * 2160L && enabledFeatures.Count >= 2)
                Add(report, HealthSeverity.Warning, "SceneView", "高解像度SceneViewでEffectsが有効",
                    $"{width}x{height} / {string.Join(", ", enabledFeatures)}",
                    "作業中だけLighting、Effects、Particleを切るか、SceneViewを小さくしてください。");

            Add(report, HealthSeverity.Info, "SceneView", "現在のSceneView設定",
                $"{width}x{height} / DrawMode {view.cameraMode.name} / " +
                (enabledFeatures.Count == 0 ? "追加Effectsなし" : string.Join(", ", enabledFeatures)),
                "SceneView右上のEffects、Lighting、Gizmoを必要な時だけ有効にしてください。");
        }

        private static bool GetSceneViewState(SceneView view, string propertyName)
        {
            try
            {
                object state = view.sceneViewState;
                var property = state.GetType().GetProperty(
                    propertyName,
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                return property != null && property.PropertyType == typeof(bool) &&
                       (bool)property.GetValue(state);
            }
            catch
            {
                return false;
            }
        }

        private static void ScanOpenSceneEssentials(HealthReport report)
        {
            const int maxIntegrityFindings = 80;
            int integrityFindings = 0;
            var sceneControllers = new Dictionary<RuntimeAnimatorController, int>();

            for (int sceneIndex = 0; sceneIndex < SceneManager.sceneCount; sceneIndex++)
            {
                var scene = SceneManager.GetSceneAt(sceneIndex);
                if (!scene.IsValid() || !scene.isLoaded)
                    continue;

                var stack = new Stack<Transform>();
                foreach (var root in scene.GetRootGameObjects())
                {
                    if (root != null)
                        stack.Push(root.transform);
                }

                while (stack.Count > 0)
                {
                    var transform = stack.Pop();
                    if (transform == null)
                        continue;

                    var gameObject = transform.gameObject;
                    if (gameObject == null)
                        continue;

                    if (integrityFindings < maxIntegrityFindings)
                    {
                        int missingScripts = GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(gameObject);
                        if (missingScripts > 0)
                        {
                            integrityFindings++;
                            Add(report, HealthSeverity.Warning, "Integrity", "Missing Script",
                                $"{GetHierarchyPath(transform)}: {missingScripts}個",
                                "不要ならMissing Componentを削除し、必要なら不足Packageを復元してください。",
                                scene.path, gameObject.GetInstanceID());
                        }

                        bool missingPrefab =
                            PrefabUtility.GetPrefabInstanceStatus(gameObject) == PrefabInstanceStatus.MissingAsset;
                        bool parentMissingPrefab =
                            transform.parent != null &&
                            PrefabUtility.GetPrefabInstanceStatus(transform.parent.gameObject) ==
                            PrefabInstanceStatus.MissingAsset;
                        if (missingPrefab && !parentMissingPrefab)
                        {
                            integrityFindings++;
                            Add(report, HealthSeverity.Warning, "Integrity", "Missing Prefab",
                                GetHierarchyPath(transform),
                                "元Prefabを復元するか、不要ならUnpackまたは削除してください。",
                                scene.path, gameObject.GetInstanceID());
                        }
                    }

                    var animator = gameObject.GetComponent<Animator>();
                    if (animator != null && animator.runtimeAnimatorController != null)
                    {
                        var controller = animator.runtimeAnimatorController;
                        if (!sceneControllers.ContainsKey(controller))
                            sceneControllers[controller] = 0;
                        sceneControllers[controller]++;
                    }

                    for (int i = 0; i < transform.childCount; i++)
                        stack.Push(transform.GetChild(i));
                }
            }

            foreach (var pair in sceneControllers.OrderByDescending(x => x.Value))
            {
                string path = AssetDatabase.GetAssetPath(pair.Key);
                if (string.IsNullOrEmpty(path))
                    continue;

                long bytes = GetAssetBytes(path);
                if (bytes < 25 * MB)
                    continue;

                Add(report,
                    bytes >= 50 * MB ? HealthSeverity.Critical : HealthSeverity.Warning,
                    "Animator",
                    $"Sceneで使っている重いAnimator: {pair.Key.name}",
                    $"{FormatBytes(bytes)} / Animator {pair.Value}個から参照: {path}",
                    "削除候補ではありません。不要なLayer、Transition、BlendTreeを減らせるか確認してください。",
                    path);
            }
        }

        private static void ScanOpenScenes(HealthReport report)
        {
            int totalObjects = 0;
            int totalBehaviours = 0;
            int totalSkinned = 0;
            int totalAnimators = 0;
            int totalMissing = 0;

            for (int sceneIndex = 0; sceneIndex < SceneManager.sceneCount; sceneIndex++)
            {
                var scene = SceneManager.GetSceneAt(sceneIndex);
                if (!scene.isLoaded)
                    continue;

                var roots = scene.GetRootGameObjects();
                var transforms = roots.SelectMany(r => r.GetComponentsInChildren<Transform>(true)).ToArray();
                var behaviours = roots.SelectMany(r => r.GetComponentsInChildren<MonoBehaviour>(true)).ToArray();
                var skinned = roots.SelectMany(r => r.GetComponentsInChildren<SkinnedMeshRenderer>(true)).ToArray();
                var animators = roots.SelectMany(r => r.GetComponentsInChildren<Animator>(true)).ToArray();
                var particles = roots.SelectMany(r => r.GetComponentsInChildren<ParticleSystem>(true)).ToArray();
                var lights = roots.SelectMany(r => r.GetComponentsInChildren<Light>(true)).ToArray();
                var colliders = roots.SelectMany(r => r.GetComponentsInChildren<Collider>(true)).ToArray();
                var rigidbodies = roots.SelectMany(r => r.GetComponentsInChildren<Rigidbody>(true)).ToArray();
                var activeSkinned = skinned
                    .Where(r => r != null && r.enabled && r.gameObject.activeInHierarchy)
                    .ToArray();
                long activeSkinnedVertices = activeSkinned
                    .Where(r => r.sharedMesh != null)
                    .Sum(r => (long)r.sharedMesh.vertexCount);
                long loadedSkinnedVertices = skinned
                    .Where(r => r != null && r.sharedMesh != null)
                    .Sum(r => (long)r.sharedMesh.vertexCount);
                long activeSkinnedBones = activeSkinned
                    .Where(r => r != null && r.bones != null)
                    .Sum(r => (long)r.bones.Length);

                var missingScriptObjects = transforms
                    .Select(t => new
                    {
                        gameObject = t.gameObject,
                        count = GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(t.gameObject)
                    })
                    .Where(x => x.count > 0)
                    .ToArray();
                int missing = missingScriptObjects.Sum(x => x.count);
                var missingPrefabs = transforms
                    .Select(t => t.gameObject)
                    .Where(go => PrefabUtility.GetPrefabInstanceStatus(go) == PrefabInstanceStatus.MissingAsset)
                    .Where(go => go.transform.parent == null ||
                                 PrefabUtility.GetPrefabInstanceStatus(go.transform.parent.gameObject) !=
                                 PrefabInstanceStatus.MissingAsset)
                    .ToArray();
                totalObjects += transforms.Length;
                totalBehaviours += behaviours.Length;
                totalSkinned += skinned.Length;
                totalAnimators += animators.Length;
                totalMissing += missing;

                if (transforms.Length >= 2500)
                    Add(report, HealthSeverity.Critical, "Scene", $"巨大なシーン: {scene.name}",
                        $"GameObjectが{transforms.Length:N0}個あります。Hierarchy・Undo・Scene保存・Editor監視の負荷が高くなります。",
                        "編集対象を複数Sceneへ分割するか、普段使わないアバターをPrefab/別Sceneへ退避してください。",
                        scene.path);
                else if (transforms.Length >= 1200)
                    Add(report, HealthSeverity.Warning, "Scene", $"大きなシーン: {scene.name}",
                        $"GameObjectが{transforms.Length:N0}個あります。",
                        "同時に編集するルートを減らすとEditor操作が軽くなります。", scene.path);

                if (behaviours.Length >= 1500)
                    Add(report, HealthSeverity.Critical, "Scene", "MonoBehaviourが非常に多い",
                        $"{scene.name}: {behaviours.Length:N0}個。ExecuteAlways、Editor監視、OnValidateの影響が増幅します。",
                        "ツール用オブジェクトや複製アバターを必要な時だけロードしてください。", scene.path);
                else if (behaviours.Length >= 700)
                    Add(report, HealthSeverity.Warning, "Scene", "MonoBehaviourが多い",
                        $"{scene.name}: {behaviours.Length:N0}個あります。",
                        "使用していないツールコンポーネントや複製を整理してください。", scene.path);

                if (activeSkinned.Length >= 100)
                    Add(report, HealthSeverity.Critical, "Rendering", "SkinnedMeshRendererが非常に多い",
                        $"{scene.name}: 有効 {activeSkinned.Length} / 読込済み {skinned.Length}。" +
                        "SceneViewの描画・Bounds更新に影響します。",
                        "非編集アバターを別Sceneへ分けるか、Scene Visibilityで非表示にしてください。", scene.path);
                else if (activeSkinned.Length >= 50)
                    Add(report, HealthSeverity.Warning, "Rendering", "SkinnedMeshRendererが多い",
                        $"{scene.name}: 有効 {activeSkinned.Length} / 読込済み {skinned.Length}。",
                        "同時表示数を減らしてください。", scene.path);

                if (activeSkinnedVertices >= 2000000 || activeSkinnedBones >= 5000)
                    Add(report, HealthSeverity.Critical, "Rendering", "スキニング対象が非常に大きい",
                        $"{scene.name}: 有効 {activeSkinnedVertices:N0} vertices / " +
                        $"bone参照 {activeSkinnedBones:N0}。読込済み総頂点 {loadedSkinnedVertices:N0}",
                        "非編集アバターを別Sceneへ分け、SceneViewで同時描画するSkinnedMeshを減らしてください。",
                        scene.path);
                else if (activeSkinnedVertices >= 750000)
                    Add(report, HealthSeverity.Warning, "Rendering", "スキニング頂点数が多い",
                        $"{scene.name}: 有効 {activeSkinnedVertices:N0} vertices / " +
                        $"読込済み総頂点 {loadedSkinnedVertices:N0}",
                        "衣装やアバターを同時表示しすぎていないか確認してください。", scene.path);

                if (loadedSkinnedVertices >= 3000000 &&
                    activeSkinnedVertices < loadedSkinnedVertices / 3)
                    Add(report, HealthSeverity.Info, "Scene Memory", "非アクティブなSkinnedMeshが大量",
                        $"{scene.name}: 有効 {activeSkinnedVertices:N0} / " +
                        $"非アクティブ込み {loadedSkinnedVertices:N0} vertices。" +
                        "描画負荷は低いですがScene読込・保存・メモリ・一部Editorツールには影響します。",
                        "描画のために消す必要はありません。Scene読込や保存が遅い場合だけ別Sceneへの分離を検討してください。",
                        scene.path);

                if (particles.Length >= 100)
                    Add(report, HealthSeverity.Warning, "Rendering", "ParticleSystemが多い",
                        $"{scene.name}: {particles.Length}個あります。",
                        "SceneView Effectsを切る、非編集ルートを非表示にする、停止中Previewを無効化してください。",
                        scene.path);

                if (lights.Length >= 20)
                    Add(report, HealthSeverity.Warning, "Rendering", "Lightが多い",
                        $"{scene.name}: {lights.Length}個あります。",
                        "Realtime Light、Shadow、SceneView Lightingの同時使用を見直してください。", scene.path);

                if (colliders.Length >= 500 || rigidbodies.Length >= 100)
                    Add(report, HealthSeverity.Warning, "Physics", "Physics Componentが多い",
                        $"{scene.name}: Collider {colliders.Length:N0} / Rigidbody {rigidbodies.Length:N0}",
                        "不要なCollider、Editor Preview、常時Simulationを確認してください。", scene.path);

                if (missing > 0)
                    foreach (var item in missingScriptObjects)
                        Add(report, HealthSeverity.Warning, "Integrity", "Missing Script",
                            $"{GetHierarchyPath(item.gameObject.transform)}: {item.count}個",
                            "不要ならMissing Componentを削除し、必要なら不足Packageを復元してください。",
                            scene.path, item.gameObject.GetInstanceID());

                foreach (var missingPrefab in missingPrefabs)
                    Add(report, HealthSeverity.Critical, "Integrity", "Missing Prefab参照",
                        $"{scene.name}: {GetHierarchyPath(missingPrefab.transform)}",
                        "元Prefabを再導入するか、意図的に壊したInstanceならUnpackまたは削除してください。",
                        scene.path, missingPrefab.GetInstanceID());

                ScanToolComponents(report, scene, behaviours);
                ScanPreviewRoots(report, scene, roots);
                ScanAnimatorInstances(report, scene, animators);
            }

            Add(report, HealthSeverity.Info, "Summary", "開いているSceneの集計",
                $"GameObject {totalObjects:N0} / MonoBehaviour {totalBehaviours:N0} / " +
                $"SkinnedMeshRenderer {totalSkinned:N0} / Animator {totalAnimators:N0} / Missing Script {totalMissing:N0}",
                "");
        }

        private static void ScanToolComponents(HealthReport report, Scene scene, MonoBehaviour[] behaviours)
        {
            var typeGroups = behaviours
                .Where(b => b != null)
                .GroupBy(b => b.GetType().FullName ?? b.GetType().Name)
                .OrderByDescending(g => g.Count())
                .ToArray();

            foreach (var group in typeGroups.Where(g => g.Count() >= 100).Take(20))
            {
                Add(report,
                    group.Count() >= 500 ? HealthSeverity.Critical : HealthSeverity.Warning,
                    "Components",
                    $"同一コンポーネントが大量: {ShortType(group.Key)}",
                    $"{scene.name}: {group.Count():N0}個あります。Editor拡張が各要素を監視すると待機中もCPUを消費します。",
                    "設計上必要か確認し、重複・古い生成物・不要メニュー項目を整理してください。",
                    scene.path);
            }

            var faceEmo = behaviours
                .Where(b => b != null && b.GetType().Name == "FaceEmoLauncherComponent")
                .ToArray();

            var targetIds = new Dictionary<int, List<MonoBehaviour>>();
            foreach (var launcher in faceEmo)
            {
                var target = FindNestedObjectReference(launcher, "AV3Setting", "TargetAvatar");
                if (target == null)
                {
                    Add(report, HealthSeverity.Warning, "Tool Data", "参照切れFaceEmo候補",
                        $"{launcher.gameObject.name}: TargetAvatar参照がありません。",
                        "バックアップ確認後、このFaceEmoランチャーが不要なら削除してください。",
                        scene.path, launcher.gameObject.GetInstanceID());
                    continue;
                }

                if (!targetIds.TryGetValue(target.GetInstanceID(), out var launchers))
                {
                    launchers = new List<MonoBehaviour>();
                    targetIds[target.GetInstanceID()] = launchers;
                }
                launchers.Add(launcher);
            }

            foreach (var duplicate in targetIds.Values.Where(v => v.Count > 1))
            {
                Add(report, HealthSeverity.Warning, "Tool Data", "同一アバターを参照するFaceEmoが複数",
                    string.Join(", ", duplicate.Select(x => x.gameObject.name)),
                    "意図的な複数設定でなければ古い方を整理してください。", scene.path);
            }
        }

        private static Object FindNestedObjectReference(Object owner, string firstProperty, string nestedProperty)
        {
            if (owner == null)
                return null;

            var serialized = new SerializedObject(owner);
            var first = serialized.FindProperty(firstProperty);
            if (first == null || first.propertyType != SerializedPropertyType.ObjectReference ||
                first.objectReferenceValue == null)
                return null;

            var nested = new SerializedObject(first.objectReferenceValue).FindProperty(nestedProperty);
            return nested != null && nested.propertyType == SerializedPropertyType.ObjectReference
                ? nested.objectReferenceValue
                : null;
        }

        private static void ScanPreviewRoots(HealthReport report, Scene scene, GameObject[] roots)
        {
            foreach (var root in roots)
            {
                string lower = root.name.ToLowerInvariant();
                if (!lower.Contains("preview") && !lower.Contains("temporary") && !lower.Contains("clone"))
                    continue;

                int children = root.GetComponentsInChildren<Transform>(true).Length - 1;
                if (children <= 0)
                    continue;

                Add(report,
                    children >= 500 ? HealthSeverity.Critical : HealthSeverity.Warning,
                    "Preview",
                    $"Preview/作業用ルート: {root.name}",
                    $"{children:N0}個の子GameObjectがあります。作業用クローンがSceneに保存されている可能性があります。",
                    "使用中ツールの仕様を確認し、ツールの正規クリーンアップ機能を優先してください。",
                    scene.path, root.GetInstanceID());
            }
        }

        private static void ScanAnimatorInstances(HealthReport report, Scene scene, Animator[] animators)
        {
            var controllers = animators
                .Where(a => a != null && a.runtimeAnimatorController != null)
                .GroupBy(a => a.runtimeAnimatorController)
                .OrderByDescending(g => g.Count());

            foreach (var group in controllers)
            {
                string path = AssetDatabase.GetAssetPath(group.Key);
                if (string.IsNullOrEmpty(path))
                    continue;

                long bytes = GetAssetBytes(path);
                if (bytes >= 25 * MB)
                    Add(report,
                        bytes >= 50 * MB ? HealthSeverity.Critical : HealthSeverity.Warning,
                        "Animator",
                        $"巨大ControllerをSceneで使用: {group.Key.name}",
                        $"{FormatBytes(bytes)} / Animator {group.Count()}個から参照。",
                        "生成元ツールの設定や重複レイヤーを確認してください。ControllerをInspectorで開きっぱなしにしないことも有効です。",
                        path);
            }
        }

        private static void ScanProjectStructure(HealthReport report)
        {
            var assetFiles = Directory.EnumerateFiles(Application.dataPath, "*", SearchOption.AllDirectories)
                .Where(p => !p.EndsWith(".meta", StringComparison.OrdinalIgnoreCase))
                .ToArray();
            long bytes = assetFiles.Sum(p => new FileInfo(p).Length);
            int scripts = assetFiles.Count(p => p.EndsWith(".cs", StringComparison.OrdinalIgnoreCase));
            int asmdefs = assetFiles.Count(p => p.EndsWith(".asmdef", StringComparison.OrdinalIgnoreCase));

            if (assetFiles.Length >= 30000)
                Add(report, HealthSeverity.Critical, "Project", "Assetsファイル数が非常に多い",
                    $"{assetFiles.Length:N0} files / {FormatBytes(bytes)}",
                    "使用しない衣装・PSD・ツールは別プロジェクトまたは保管フォルダへ分離してください。");
            else if (assetFiles.Length >= 15000)
                Add(report, HealthSeverity.Warning, "Project", "Assetsファイル数が多い",
                    $"{assetFiles.Length:N0} files / {FormatBytes(bytes)}",
                    "AssetDatabase Refresh、バックアップ、検索時間が長くなります。");

            Add(report, HealthSeverity.Info, "Summary", "Assets集計",
                $"{assetFiles.Length:N0} files / {FormatBytes(bytes)} / C# {scripts:N0} / asmdef {asmdefs:N0}", "");

            if (scripts >= 500 && asmdefs <= 2)
                Add(report, HealthSeverity.Warning, "Compilation", "C# Scriptに対してasmdefが少ない",
                    $"C# {scripts:N0} files / asmdef {asmdefs:N0}。小さな変更でも巨大Assemblyを再コンパイルしやすい状態です。",
                    "自作ツールをRuntime/Editor単位のasmdefへ分割してください。購入Assetは無理に編集しないでください。");

            string normalizedPath = Application.dataPath.Replace('\\', '/').ToLowerInvariant();
            if (normalizedPath.Contains("/onedrive/") || normalizedPath.Contains("/dropbox/") ||
                normalizedPath.Contains("/google drive/") || normalizedPath.Contains("/googledrive/"))
                Add(report, HealthSeverity.Critical, "Storage", "クラウド同期フォルダ内のUnity Project",
                    Application.dataPath,
                    "Library/Tempを含む大量の小ファイル同期で極端に遅くなるため、ローカルSSDへ移動してください。");

            int buildReports = assetFiles.Count(p =>
                p.EndsWith(".buildreport", StringComparison.OrdinalIgnoreCase));
            if (buildReports > 0)
                Add(report, HealthSeverity.Warning, "Generated Files", "BuildReportがAssets内に存在",
                    $"{buildReports}個。書き換えのたびにAssetDatabase Refresh対象になります。",
                    "Assets外のLogs/や専用出力フォルダへ保存してください。");
        }

        private static void ScanAssets(HealthReport report)
        {
            var paths = AssetDatabase.GetAllAssetPaths()
                .Where(p => p.StartsWith("Assets/", StringComparison.Ordinal))
                .ToArray();

            var filePaths = paths.Where(p => !AssetDatabase.IsValidFolder(p)).ToArray();
            var fileSizes = filePaths.ToDictionary(p => p, GetAssetBytes, StringComparer.OrdinalIgnoreCase);
            var referenceTargetPaths = filePaths
                .Where(IsReferenceCountTarget)
                .ToArray();
            var inboundReferences = BuildInboundReferenceCounts(
                filePaths,
                referenceTargetPaths,
                out var externallyUsedPackages);
            var openSceneTexturePaths = CollectOpenSceneTexturePaths();
            ScanUnusedPackages(report, filePaths, externallyUsedPackages, fileSizes);

            for (int i = 0; i < paths.Length; i++)
            {
                string path = paths[i];
                if (i % 250 == 0)
                    EditorUtility.DisplayProgressBar("Project Health Scanner",
                        $"Scanning assets {i:N0}/{paths.Length:N0}", paths.Length == 0 ? 1 : (float)i / paths.Length);

                if (AssetDatabase.IsValidFolder(path))
                    continue;

                long bytes = GetCachedAssetBytes(fileSizes, path);
                string extension = Path.GetExtension(path).ToLowerInvariant();

                if (IsDirectChildOfAssets(path))
                    ScanUnusedLooseAsset(report, path, extension, bytes, inboundReferences);

                bool textureFile = IsTextureExtension(extension);
                if (!textureFile && bytes >= 100 * MB)
                    Add(report, HealthSeverity.Critical, "Asset Size", "100MB超のアセット",
                        $"{FormatBytes(bytes)}: {path}", "元データをUnity外で保管する、解像度を落とす、不要なら除外してください。", path,
                        sizeBytes: bytes);
                else if (!textureFile && bytes >= 50 * MB)
                    Add(report, HealthSeverity.Warning, "Asset Size", "50MB超のアセット",
                        $"{FormatBytes(bytes)}: {path}", "インポート・バックアップ・Library生成コストを確認してください。", path,
                        sizeBytes: bytes);

                if (extension == ".controller")
                    ScanAnimatorController(report, path, bytes, inboundReferences);
                else if (textureFile)
                    ScanTexture(report, path, bytes, openSceneTexturePaths);
                else if ((extension == ".psd" || extension == ".psb") && bytes >= 100 * MB)
                    Add(report, HealthSeverity.Warning, "Source Asset", "大きいPSD/PSB",
                        $"{FormatBytes(bytes)}: {path}",
                        "編集元ファイルはUnity外へ保管し、Unityには書き出した画像だけを入れると軽くなります。", path,
                        sizeBytes: bytes);
                else if (extension == ".unity" && bytes >= 10 * MB)
                    Add(report, bytes >= 20 * MB ? HealthSeverity.Critical : HealthSeverity.Warning,
                        "Scene", "Sceneファイルが巨大", $"{FormatBytes(bytes)}: {path}",
                        "複数Sceneへ分割し、生成データや複製ルートを整理してください。", path,
                        sizeBytes: bytes);
            }
        }

        private static Dictionary<string, int> BuildInboundReferenceCounts(
            string[] paths,
            string[] referenceTargetPaths,
            out HashSet<string> externallyUsedPackages)
        {
            var counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            externallyUsedPackages = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string path in referenceTargetPaths)
                counts[path] = 0;

            var allGuidToPath = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (string path in paths)
            {
                string guid = AssetDatabase.AssetPathToGUID(path);
                if (!string.IsNullOrEmpty(guid) && !allGuidToPath.ContainsKey(guid))
                    allGuidToPath.Add(guid, path);
            }

            foreach (var editorScene in EditorBuildSettings.scenes.Where(s => s.enabled))
            {
                string root = GetAssetsPackageRoot(editorScene.path);
                if (!string.IsNullOrEmpty(root))
                    externallyUsedPackages.Add(root);
            }
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                string root = GetAssetsPackageRoot(SceneManager.GetSceneAt(i).path);
                if (!string.IsNullOrEmpty(root))
                    externallyUsedPackages.Add(root);
            }

            var sources = paths.Where(IsSerializedReferenceSource).ToArray();
            string projectRoot = Directory.GetParent(Application.dataPath)?.FullName ?? Application.dataPath;
            for (int i = 0; i < sources.Length; i++)
            {
                if (i % 100 == 0)
                    EditorUtility.DisplayProgressBar("Project Health Scanner",
                        $"Building reference graph {i:N0}/{sources.Length:N0}",
                        sources.Length == 0 ? 1 : (float)i / sources.Length);

                string source = sources[i];
                string sourceRoot = GetAssetsPackageRoot(source);
                string fullPath = AssetPathToFullPath(projectRoot, source);

                foreach (string guid in ExtractGuidReferences(fullPath))
                {
                    if (!allGuidToPath.TryGetValue(guid, out string dependency))
                        continue;
                    if (string.Equals(source, dependency, StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (counts.ContainsKey(dependency))
                        counts[dependency]++;

                    string dependencyRoot = GetAssetsPackageRoot(dependency);
                    if (!string.IsNullOrEmpty(dependencyRoot) &&
                        !string.Equals(dependencyRoot, sourceRoot, StringComparison.OrdinalIgnoreCase))
                        externallyUsedPackages.Add(dependencyRoot);
                }
            }

            return counts;
        }

        private static string AssetPathToFullPath(string projectRoot, string assetPath)
        {
            return Path.Combine(projectRoot, assetPath.Replace('/', Path.DirectorySeparatorChar));
        }

        private static IEnumerable<string> ExtractGuidReferences(string fullPath)
        {
            if (string.IsNullOrEmpty(fullPath) || !File.Exists(fullPath))
                yield break;

            IEnumerable<string> lines;
            try { lines = File.ReadLines(fullPath); }
            catch { yield break; }

            foreach (string line in lines)
            {
                int index = 0;
                while (true)
                {
                    index = line.IndexOf("guid:", index, StringComparison.Ordinal);
                    if (index < 0)
                        break;

                    index += 5;
                    while (index < line.Length && char.IsWhiteSpace(line[index]))
                        index++;

                    if (index + 32 <= line.Length)
                    {
                        string guid = line.Substring(index, 32);
                        if (IsGuidLike(guid))
                            yield return guid;
                    }
                }
            }
        }

        private static bool IsGuidLike(string value)
        {
            if (string.IsNullOrEmpty(value) || value.Length != 32)
                return false;
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                bool hex = (c >= '0' && c <= '9') ||
                           (c >= 'a' && c <= 'f') ||
                           (c >= 'A' && c <= 'F');
                if (!hex)
                    return false;
            }
            return true;
        }

        private static HashSet<string> CollectOpenSceneAnimatorControllerPaths()
        {
            var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                var scene = SceneManager.GetSceneAt(i);
                if (!scene.IsValid() || !scene.isLoaded)
                    continue;

                foreach (var root in scene.GetRootGameObjects())
                {
                    foreach (var animator in root.GetComponentsInChildren<Animator>(true))
                    {
                        if (animator == null || animator.runtimeAnimatorController == null)
                            continue;

                        AddAnimatorControllerPath(paths, animator.runtimeAnimatorController);
                    }
                }
            }

            return paths;
        }

        private static HashSet<string> CollectOpenSceneTexturePaths()
        {
            var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                var scene = SceneManager.GetSceneAt(i);
                if (!scene.IsValid() || !scene.isLoaded)
                    continue;

                foreach (var root in scene.GetRootGameObjects())
                {
                    foreach (var renderer in root.GetComponentsInChildren<Renderer>(true))
                    {
                        if (renderer == null)
                            continue;

                        foreach (var material in renderer.sharedMaterials)
                            AddMaterialTexturePaths(paths, material);
                    }

                    foreach (var spriteRenderer in root.GetComponentsInChildren<SpriteRenderer>(true))
                    {
                        if (spriteRenderer == null || spriteRenderer.sprite == null ||
                            spriteRenderer.sprite.texture == null)
                            continue;

                        AddTexturePath(paths, spriteRenderer.sprite.texture);
                    }
                }
            }

            return paths;
        }

        private static void AddMaterialTexturePaths(HashSet<string> paths, Material material)
        {
            if (material == null)
                return;

            string[] names;
            try { names = material.GetTexturePropertyNames(); }
            catch { return; }

            foreach (string name in names)
            {
                Texture texture;
                try { texture = material.GetTexture(name); }
                catch { continue; }

                AddTexturePath(paths, texture);
            }
        }

        private static void AddTexturePath(HashSet<string> paths, Texture texture)
        {
            if (texture == null)
                return;

            string path = AssetDatabase.GetAssetPath(texture);
            if (!string.IsNullOrEmpty(path))
                paths.Add(path);
        }

        private static void AddAnimatorControllerPath(HashSet<string> paths, RuntimeAnimatorController controller)
        {
            if (controller == null)
                return;

            string path = AssetDatabase.GetAssetPath(controller);
            if (!string.IsNullOrEmpty(path))
                paths.Add(path);

            var overrideController = controller as AnimatorOverrideController;
            if (overrideController != null)
                AddAnimatorControllerPath(paths, overrideController.runtimeAnimatorController);
        }

        private static bool IsSerializedReferenceSource(string path)
        {
            string extension = Path.GetExtension(path).ToLowerInvariant();
            return extension == ".unity" || extension == ".prefab" || extension == ".asset" ||
                   extension == ".controller" || extension == ".overridecontroller" ||
                   extension == ".anim";
        }

        private static bool IsReferenceCountTarget(string path)
        {
            string extension = Path.GetExtension(path).ToLowerInvariant();
            if (extension == ".controller")
                return true;

            return IsDirectChildOfAssets(path) &&
                   IsUnusedCandidateExtension(extension) &&
                   !IsProtectedOrDynamicPath(path);
        }

        private static void ScanUnusedPackages(
            HealthReport report,
            string[] paths,
            HashSet<string> externallyUsedPackages,
            Dictionary<string, long> fileSizes)
        {
            var packages = paths
                .Select(path => new { path, root = GetAssetsPackageRoot(path) })
                .Where(x => !string.IsNullOrEmpty(x.root))
                .GroupBy(x => x.root, StringComparer.OrdinalIgnoreCase);

            foreach (var package in packages)
            {
                string root = package.Key;
                var packagePaths = package.Select(x => x.path).ToArray();
                if (IsProtectedOrDynamicPath(root) ||
                    packagePaths.Any(IsPackageAutomaticallyUsedFile))
                    continue;

                bool used = externallyUsedPackages.Contains(root) ||
                            packagePaths.Any(HasAssetBundleName);
                if (used)
                    continue;

                long totalBytes = packagePaths.Sum(path => GetCachedAssetBytes(fileSizes, path));
                Add(report, HealthSeverity.Warning, "Unused / Package",
                    "丸ごと未使用のPackageフォルダ候補",
                    $"{packagePaths.Length:N0} files / {FormatBytes(totalBytes)}: {root}",
                    "フォルダ内のどのアセットもProjectから参照されていません。" +
                    "購入Assetの保管目的や手動利用予定がなければ、フォルダ単位で削除してください。",
                    root,
                    sizeBytes: totalBytes);
            }
        }

        private static void ScanUnusedLooseAsset(
            HealthReport report,
            string path,
            string extension,
            long bytes,
            Dictionary<string, int> inboundReferences)
        {
            if (!inboundReferences.TryGetValue(path, out int inbound) || inbound > 0)
                return;
            if (!IsUnusedCandidateExtension(extension) || IsProtectedOrDynamicPath(path))
                return;

            var importer = AssetImporter.GetAtPath(path);
            if (importer != null && !string.IsNullOrEmpty(importer.assetBundleName))
                return;

            bool generated = path.IndexOf(GeneratedResourcesMarker,
                StringComparison.OrdinalIgnoreCase) >= 0;
            if (generated)
            {
                Add(report, HealthSeverity.Critical, "Unused / 高確度",
                    "参照されていない生成アセット",
                    $"{FormatBytes(bytes)}: {path}",
                    "生成元ツールで再生成できることを確認し、このフォルダ内の候補をまとめて削除してください。",
                    path,
                    sizeBytes: bytes);
                return;
            }

            Add(report, HealthSeverity.Warning, "Unused / 要確認",
                "Project内のどこからも参照されていないアセット",
                $"{FormatBytes(bytes)}: {path}",
                "Resources等の動的ロードで使っていないことを確認し、不要なら削除してください。",
                path,
                sizeBytes: bytes);
        }

        private static string GetAssetsPackageRoot(string path)
        {
            string normalized = path.Replace('\\', '/');
            string[] parts = normalized.Split('/');
            return parts.Length >= 3 && parts[0] == "Assets"
                ? "Assets/" + parts[1]
                : null;
        }

        private static bool IsDirectChildOfAssets(string path)
        {
            string normalized = path.Replace('\\', '/');
            return normalized.StartsWith("Assets/", StringComparison.Ordinal) &&
                   normalized.Count(c => c == '/') == 1;
        }

        private static bool IsPackageAutomaticallyUsedFile(string path)
        {
            if (IsProtectedOrDynamicPath(path))
                return true;

            string extension = Path.GetExtension(path).ToLowerInvariant();
            if (extension == ".cs" || extension == ".asmdef" || extension == ".asmref" ||
                extension == ".dll" || extension == ".aar" || extension == ".jar" ||
                extension == ".shader" || extension == ".cginc" || extension == ".hlsl" ||
                extension == ".compute" || extension == ".rsp")
                return true;

            string fileName = Path.GetFileName(path);
            return string.Equals(fileName, "package.json", StringComparison.OrdinalIgnoreCase);
        }

        private static bool HasAssetBundleName(string path)
        {
            var importer = AssetImporter.GetAtPath(path);
            return importer != null && !string.IsNullOrEmpty(importer.assetBundleName);
        }

        private static bool IsUnusedCandidateExtension(string extension)
        {
            return IsTextureExtension(extension) || IsModelExtension(extension) ||
                   IsAudioExtension(extension) || extension == ".mat" ||
                   extension == ".anim" || extension == ".controller" ||
                   extension == ".overridecontroller" || extension == ".prefab" ||
                   extension == ".asset" || extension == ".mask" ||
                   extension == ".physicmaterial" || extension == ".physicsmaterial2d";
        }

        private static bool IsProtectedOrDynamicPath(string path)
        {
            string normalized = "/" + path.Replace('\\', '/').ToLowerInvariant() + "/";
            return normalized.Contains("/resources/") ||
                   normalized.Contains("/streamingassets/") ||
                   normalized.Contains("/editor/") ||
                   normalized.Contains("/plugins/") ||
                   normalized.Contains("/gizmos/") ||
                   normalized.Contains("/editor default resources/") ||
                   normalized.Contains("/mim/project health scanner/");
        }

        private static void ScanAnimatorController(
            HealthReport report,
            string path,
            long bytes,
            Dictionary<string, int> inboundReferences)
        {
            var controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(path);
            if (controller == null)
                return;

            int states = 0;
            int transitions = 0;
            int blendTrees = 0;
            foreach (var layer in controller.layers)
                CountStateMachine(layer.stateMachine, ref states, ref transitions, ref blendTrees);

            if (bytes >= 25 * MB || states >= 250 || transitions >= 1000)
            {
                inboundReferences.TryGetValue(path, out int inbound);
                bool deletableUnused = inbound <= 0 &&
                                       !HasAssetBundleName(path) &&
                                       !IsProtectedOrDynamicPath(path);

                if (deletableUnused)
                {
                    Add(report,
                        bytes >= 50 * MB || transitions >= 1500 ? HealthSeverity.Critical : HealthSeverity.Warning,
                        "Unused / Animator",
                        $"使われていないAnimator Controller: {controller.name}",
                        $"{FormatBytes(bytes)}, Layers {controller.layers.Length}, States {states}, " +
                        $"Transitions {transitions}, BlendTrees {blendTrees}: {path}",
                        "Scene・Prefab・他Assetから参照されていないAnimator Controllerです。不要なら削除候補として確認してください。",
                        path,
                        sizeBytes: bytes);
                    return;
                }

                Add(report,
                    bytes >= 50 * MB || transitions >= 1500 ? HealthSeverity.Critical : HealthSeverity.Warning,
                    "Animator",
                    $"肥大化Animator Controller: {controller.name}",
                    $"{FormatBytes(bytes)}, Layers {controller.layers.Length}, States {states}, " +
                    $"Transitions {transitions}, BlendTrees {blendTrees}",
                    "自動生成の複製、全状態間Transition、不要レイヤー、巨大BlendTreeを確認してください。",
                    path,
                    sizeBytes: bytes);
            }

        }

        private static void CountStateMachine(
            AnimatorStateMachine machine, ref int states, ref int transitions, ref int blendTrees)
        {
            if (machine == null)
                return;

            states += machine.states.Length;
            transitions += machine.anyStateTransitions.Length + machine.entryTransitions.Length;
            foreach (var child in machine.states)
            {
                transitions += child.state.transitions.Length;
                CountMotion(child.state.motion, ref blendTrees);
            }

            foreach (var child in machine.stateMachines)
                CountStateMachine(child.stateMachine, ref states, ref transitions, ref blendTrees);
        }

        private static void CountMotion(Motion motion, ref int blendTrees)
        {
            if (!(motion is BlendTree tree))
                return;
            blendTrees++;
            foreach (var child in tree.children)
                CountMotion(child.motion, ref blendTrees);
        }

        private static void ScanTexture(HealthReport report, string path, long bytes, HashSet<string> openSceneTexturePaths)
        {
            var importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer == null)
                return;

            int width;
            int height;
            try
            {
                importer.GetSourceTextureWidthAndHeight(out width, out height);
            }
            catch
            {
                return;
            }

            if (width >= 3840 || height >= 3840)
            {
                bool usedInOpenScene = openSceneTexturePaths != null && openSceneTexturePaths.Contains(path);
                string title = usedInOpenScene
                    ? "4Kテクスチャ（Scene内で使用中）"
                    : "4Kテクスチャ（Scene内では未使用）";
                Add(report, HealthSeverity.Warning, "Texture", title,
                    $"{width}x{height} / {FormatBytes(bytes)}: {path}",
                    "必要以上に大きい場合はMax Sizeを下げる、または用途に合わせて圧縮設定を見直してください。",
                    path,
                    sizeBytes: bytes);
            }
        }

        private static void ScanModel(HealthReport report, string path)
        {
            var importer = AssetImporter.GetAtPath(path) as ModelImporter;
            if (importer == null || !importer.isReadable)
                return;

            var meshes = AssetDatabase.LoadAllAssetsAtPath(path).OfType<Mesh>().ToArray();
            long vertices = meshes.Sum(m => (long)m.vertexCount);
            if (vertices >= 100000)
                Add(report, HealthSeverity.Warning, "Mesh", "Read/Write有効の大型Model",
                    $"{vertices:N0} vertices: {path}",
                    "実行時にMeshを書き換えないならRead/Writeを無効化してください。", path);
        }

        private static void ScanAudio(HealthReport report, string path, long bytes)
        {
            var importer = AssetImporter.GetAtPath(path) as AudioImporter;
            if (importer == null)
                return;

            AudioImporterSampleSettings settings = importer.defaultSampleSettings;
            if (settings.loadType == AudioClipLoadType.DecompressOnLoad && bytes >= 5 * MB)
                Add(report, HealthSeverity.Warning, "Audio", "大型AudioをDecompress On Load",
                    $"{FormatBytes(bytes)}: {path}",
                    "長い音源はStreaming、効果音はCompressed In Memoryを検討してください。", path);
        }

        private static void ScanEditorCode(HealthReport report)
        {
            string[] guids = AssetDatabase.FindAssets("t:MonoScript", new[] { "Assets" });
            int initializeOnLoad = 0;
            int editorUpdate = 0;
            int executeAlways = 0;
            var constantUpdateScripts = new List<string>();
            var executeAlwaysScripts = new List<string>();

            foreach (string guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                if (!path.EndsWith(".cs", StringComparison.OrdinalIgnoreCase))
                    continue;

                string fullPath = Path.GetFullPath(path);
                string source;
                try { source = File.ReadAllText(fullPath); }
                catch { continue; }

                if (source.Contains("[InitializeOnLoad") || source.Contains("[InitializeOnLoadMethod"))
                    initializeOnLoad++;
                if (source.Contains("EditorApplication.update") || source.Contains("duringSceneGui"))
                {
                    editorUpdate++;
                    constantUpdateScripts.Add(path);
                }
                if (source.Contains("[ExecuteAlways") || source.Contains("[ExecuteInEditMode"))
                {
                    executeAlways++;
                    executeAlwaysScripts.Add(path);
                }
            }

            foreach (string path in constantUpdateScripts)
                Add(report, HealthSeverity.Warning, "Editor Extensions", "常時更新を登録するEditor Script",
                    path,
                    "不要なツールならPackage単位で外してください。自作コードなら選択中だけ動かす、更新間隔を設ける実装にしてください。",
                    path);

            foreach (string path in executeAlwaysScripts)
                Add(report, HealthSeverity.Info, "Editor Extensions", "Edit Modeでも動作するScript",
                    path,
                    "非アクティブ時や値が変わっていない時は処理をスキップしているか確認してください。",
                    path);

            Add(report, HealthSeverity.Info, "Editor Extensions", "Editor常駐コード候補",
                $"InitializeOnLoad {initializeOnLoad} / update・SceneGUI {editorUpdate} / ExecuteAlways {executeAlways}",
                "数だけで問題とは限りません。ProfilerのEditorLoopと合わせて判断してください。");
        }

        private static string GetHierarchyPath(Transform transform)
        {
            if (transform == null)
                return "(null)";

            var names = new Stack<string>();
            for (Transform current = transform; current != null; current = current.parent)
                names.Push(current.name);
            return string.Join("/", names.ToArray());
        }

        private static void ScanSettings(HealthReport report)
        {
            if (!EditorSettings.enterPlayModeOptionsEnabled)
                Add(report, HealthSeverity.Info, "Settings", "Enter Play Mode Optionsが無効",
                    "Play開始時にDomain ReloadとScene Reloadが毎回実行されます。",
                    "互換性を確認した上でProject Settings > Editorから高速化できます。");

            int packageCount = 0;
            try
            {
                string manifest = File.ReadAllText("Packages/manifest.json");
                packageCount = manifest.Split('\n').Count(line => line.Contains("\":"));
            }
            catch { }

            if (packageCount >= 35)
                Add(report, HealthSeverity.Warning, "Packages", "埋め込みPackageが多い",
                    $"manifest上に約{packageCount}個の依存があります。Scriptコンパイル・Domain Reload・Editor初期化が増えます。",
                    "使用していないツールPackageをプロジェクトから外してください。");

            int materials = AssetDatabase.FindAssets("t:Material", new[] { "Assets" }).Length;
            int animationClips = AssetDatabase.FindAssets("t:AnimationClip", new[] { "Assets" }).Length;
            if (materials >= 3000 || animationClips >= 5000)
                Add(report, HealthSeverity.Warning, "Asset Database", "MaterialまたはAnimationClipが非常に多い",
                    $"Materials {materials:N0} / AnimationClips {animationClips:N0}",
                    "未使用衣装・表情・Animation素材を別プロジェクトへ分離すると検索とRefreshが軽くなります。");
        }

        private void ExportJson()
        {
            string path = EditorUtility.SaveFilePanel(
                "Export Project Health Report",
                Directory.GetParent(Application.dataPath)?.FullName ?? Application.dataPath,
                $"ProjectHealth-{DateTime.Now:yyyyMMdd-HHmmss}.json",
                "json");
            if (string.IsNullOrEmpty(path))
                return;

            File.WriteAllText(path, JsonUtility.ToJson(_report, true), new UTF8Encoding(false));
            EditorUtility.RevealInFinder(path);
        }

        private static int CalculateScore(IEnumerable<HealthFinding> findings)
        {
            int penalty = findings.Sum(f => f.severity == HealthSeverity.Critical ? 10 :
                                            f.severity == HealthSeverity.Warning ? 3 : 0);
            return Mathf.Clamp(100 - penalty, 0, 100);
        }

        private static void Add(
            HealthReport report,
            HealthSeverity severity,
            string category,
            string title,
            string detail,
            string recommendation,
            string assetPath = "",
            int instanceId = 0,
            bool safeFix = false,
            string fixKind = "",
            long sizeBytes = 0)
        {
            report.findings.Add(new HealthFinding
            {
                severity = severity,
                category = category,
                title = title,
                detail = detail,
                recommendation = recommendation,
                assetPath = assetPath ?? "",
                instanceId = instanceId,
                safeFix = safeFix,
                fixKind = fixKind ?? "",
                sizeBytes = sizeBytes
            });
        }

        private static string ShortType(string fullName)
        {
            int dot = fullName.LastIndexOf('.');
            return dot >= 0 ? fullName.Substring(dot + 1) : fullName;
        }

        private static long GetAssetBytes(string assetPath)
        {
            try
            {
                string fullPath = Path.GetFullPath(assetPath);
                return File.Exists(fullPath) ? new FileInfo(fullPath).Length : 0;
            }
            catch
            {
                return 0;
            }
        }

        private static long GetCachedAssetBytes(Dictionary<string, long> fileSizes, string assetPath)
        {
            if (fileSizes != null && !string.IsNullOrEmpty(assetPath) &&
                fileSizes.TryGetValue(assetPath, out long bytes))
                return bytes;

            return GetAssetBytes(assetPath);
        }

        private static string FormatBytes(long bytes)
        {
            if (bytes >= 1024L * MB)
                return $"{bytes / (1024d * MB):0.00} GB";
            if (bytes >= MB)
                return $"{bytes / (double)MB:0.0} MB";
            return $"{bytes / 1024d:0.0} KB";
        }

        private static bool IsTextureExtension(string extension)
        {
            return extension == ".png" || extension == ".jpg" || extension == ".jpeg" ||
                   extension == ".tga" || extension == ".psd" || extension == ".psb" ||
                   extension == ".tif" || extension == ".tiff" || extension == ".exr";
        }

        private static bool IsModelExtension(string extension)
        {
            return extension == ".fbx" || extension == ".obj" || extension == ".blend" ||
                   extension == ".dae";
        }

        private static bool IsAudioExtension(string extension)
        {
            return extension == ".wav" || extension == ".mp3" || extension == ".ogg" ||
                   extension == ".aif" || extension == ".aiff";
        }
    }
}
