Project Health Scanner (PHS) Ver2.0.0

【どんなツールか】
UnityのHierarchyで使うアセットを保護し、参照が見つからない衣装・オブジェクト関連ファイルの整理を補助するEditorツールです。
未使用を完全に判定するものではありません。削除候補を確認してから実行してください。

【導入】
VCC / ALCOMでMiM Project Health Scannerを追加・更新します。Assets版と同時に導入しないでください。
既存版は同じパスへ上書きします。旧テクスチャ設定のバックアップは消しませんが、この版にはテクスチャ設定の復元画面はありません。
検証環境：Windows / Unity 2022.3.22f1。その他のUnityバージョン・OSは未検証です。

【基本操作】
1. 残したいアバター・衣装・オブジェクトをHierarchyに置きます。非アクティブも保護対象です。
2. MiM > Project Health Scanner > Scanを1回押します。ウィンドウが開き、そのまま調査します。
3. 未保存・変更中の通常シーンがある場合は保存確認が出ます。承認すると保存してスキャンします。キャンセルや保存失敗では進みません。
4. 必要なら「整理するフォルダ」や「追加で残すファイル・フォルダ」を変更し、再スキャンします。空欄の整理範囲はAssets全体です。
5. 削除候補を選び、容量予測と確認画面を確認して「バックアップして削除」を実行します。
コンパイル・インポート・Play Mode中は開始を待ちます。待機中にもう一度スキャンを押す必要はありません。
複数シーンの保存途中でキャンセルした場合、既に保存したシーンは保存済みのままです。

【残すもの・候補になるもの】
・ロード済みの全シーンのHierarchyと、その参照先を保護します。選択した1体だけが基準ではありません。
・初期設定では、開いていない保存済みシーンの参照も保護します。
・Prefabの接続元やその依存先は、Instanceから取り外した素材であっても残る場合があります。
・Assets直下の配布フォルダにコード、Editor、DLL、シェーダー、Resources、package.json等があれば付属素材も保護します。
・モデルを含みツールの目印がない配布フォルダだけを削除候補の範囲にします。用途不明・ツール混在フォルダは残します。
・名前による動的ロード、独自ツールのGUID文字列等は網羅できません。必要なファイルは追加の保護対象にしてください。
・参照切れは修復しません。保存済みシーンによる追加保護ができた場合のみ、参照切れが残っていても候補の削除を許可します。Missing Script / Missing Prefabは先に修復が必要です。

【確認項目】
・Package内アセットのHierarchyからの参照状況
・使用中／参照未検出のAnimator Controllerとファイル容量
・使用中／参照未検出の4K以上のテクスチャ
・50 MiBを超えるアセット、100 MiBを超えるPSD・PSB
・確認項目の優先度順／サイズ順の切り替え
確認項目は削除候補とは別です。Packageはこのツールから削除しません。
Controllerはファイル容量であり処理負荷の実測ではありません。4K判定は元画像寸法とインポート設定に基づく推定です。
テクスチャ圧縮・総合負荷診断・FPS測定機能はありません。

【容量と待ち時間】
円グラフはAssets内のファイルと.metaの容量予測です。Library、Packages、バックアップ、ごみ箱は含みません。
GBは1,000,000,000 bytes、一覧のMB表示は1,048,576 bytes（MiB）換算です。
容量の削減はFPS、VRAM、PCの空き容量の改善を保証しません。同じディスクにバックアップを作るため、一時的に追加の空き容量が必要です。ごみ箱とバックアップが残る間は、ディスクの空き容量が増えるとは限りません。
スキャン、削除、復元はUnityの操作を待たせる処理です。件数・ファイル容量・ディスク速度により時間がかかります。

【削除履歴・再インポート】
・同じウィンドウの「削除履歴・再インポート」タブで、削除日時を選びます。
・削除元の親フォルダ名（Assets直下）、ファイル名、元のパスを確認できます。
・選択した日時の履歴をファイル名・フォルダ名・GUIDで検索できます。50件ずつ表示します。
・「削除した空フォルダを確認する」で空フォルダの履歴も確認できます。
・「削除一覧TXTを開く」でDeletedAssets.txtを開きます。TXTは各バックアップ内に保存されます。
・「元のunitypackageを選んで再インポート」から、手元の元の商品Packageを選びます。Unityのインポート確認画面で内容を確認してください。
・親フォルダ名から元のPackageを自動特定・自動ダウンロードする機能はありません。同名の別商品・別バージョンに注意してください。
・再インポートでは、削除した以外の不要ファイルも戻る場合があります。
・履歴の状態はPHSの操作記録です。手動復旧・再インポート後の状態は自動更新しません。旧版や中断時の履歴は「削除処理の記録」と表示します。

【バックアップからの復元】
プロジェクト直下：ProjectHealthScannerBackups/HierarchyCleanup
ファイル・.metaをバックアップし、照合してからOSのごみ箱へ移動します。
以前から残っていた空フォルダと今回空になった親フォルダも、保護対象を除き同時に整理します。
Hierarchyから参照している空フォルダと、追加の保護対象は残します。
「最新の削除を復元」、または履歴の「この日時のバックアップを復元」が使えます。既存の異なるファイルは上書きせず保留します。
中断・失敗時は自動復元を試みます。復元は同じプロジェクトパスで行ってください。移動したプロジェクトのバックアップは自動認識しません。
バックアップフォルダを消すと、PHSでの復元と履歴表示はできなくなります。バックアップの自動削除はありません。

【更新】
Ver2.0.0：スキャン開始待ちの表示・再読込への対応、削除履歴検索・TXT・再インポート導線、参照空フォルダ保護、復元記録の保存回数削減。
更新の自動通知は未設定です。

【お問い合わせ】
https://discord.gg/cpu6ZFRJE
商品名、ツールのバージョン、使用アバター、行った操作、症状が分かる画像を添えてください。無料版／有償版の区分がある場合はその情報も添えてください。

English
PHS assists with unused asset cleanup based on all loaded scene Hierarchies, including inactive objects. Other saved scenes are protected by default. No reference is not proof of non-use.
Choose MiM > Project Health Scanner > Scan once. Accept scene saving when prompted; cancellation stops scanning. Re-scan only after changing the cleanup scope or protection settings.
Review items include package asset references, controller disk sizes, 4K textures inferred from import settings, assets over 50 MiB and PSD/PSB over 100 MiB. Review items are separate from removal candidates. No package removal, texture compression or FPS measurement is provided.
History / reimport lets you choose a removal session, search filenames, folders or GUIDs, open the TXT log and choose the original unitypackage for interactive import. Package identity is not detected automatically. Reimport may restore other unwanted files too. History records PHS operations rather than the current state after an external reimport.
Backups and DeletedAssets.txt are stored in ProjectHealthScannerBackups/HierarchyCleanup at the project root. Files, metadata and unprotected empty folders are backed up. Restore by session without overwriting conflicting files. Restoration requires the original project path. Do not delete backups while you need restoration or history.
Capacity measures Assets only, excluding Library, Packages, backups and trash; it does not predict FPS or free disk space. Extra space is needed for backups. Large operations can take time and block editor interaction.
Validated environment: Windows, Unity 2022.3.22f1. Other platforms/versions are untested. Automatic update notification is not configured.
Support: https://discord.gg/cpu6ZFRJE — include product/version, avatar, steps, symptoms and screenshots (edition if applicable).
