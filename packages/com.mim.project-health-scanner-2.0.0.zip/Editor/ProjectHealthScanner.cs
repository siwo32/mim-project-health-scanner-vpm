using UnityEditor;
using UnityEngine;

namespace ProjectHealthScanner
{
    public sealed class ProjectHealthScannerWindow : EditorWindow
    {
        public const string CurrentVersion = "2.0.0";
        public const int CurrentVersionBuild = 20000;
        public const string VersionCheckUrl = "";
        public const string ProductUrl = "";
        [SerializeField] private ProjectHealthHierarchyCleanupWindow _cleanup;
        [SerializeField] private int _language;
        [SerializeField] private bool _scanQueued;
        [SerializeField] private int _tab;
        private string QueueKey => "PHS.PendingScan." + Application.dataPath;
        internal bool ScanPending => _scanQueued;
        private string T(string jp, string en) => _language == 0 ? jp : en;
        internal ProjectHealthHierarchyCleanupWindow CleanupView
        {
            get
            {
                if (_cleanup == null)
                {
                    _cleanup = CreateInstance<ProjectHealthHierarchyCleanupWindow>();
                    _cleanup.hideFlags = HideFlags.HideAndDontSave;
                }
                _cleanup.Host = this;
                return _cleanup;
            }
        }

        [MenuItem("MiM/Project Health Scanner/Scan")]
        public static void Open()
        {
            var window = GetWindow<ProjectHealthScannerWindow>("PHS");
            window.minSize = new Vector2(620, 620);
            window.Show(); window.Focus();
            window.QueueScan();
        }

        internal void QueueScan()
        {
            _tab = 0;
            _scanQueued = true;
            SessionState.SetBool(QueueKey, true);
            EditorApplication.delayCall -= RunQueuedScan;
            EditorApplication.delayCall += RunQueuedScan;
        }

        private void RunQueuedScan()
        {
            if (!_scanQueued) return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode)
            {
                EditorApplication.update -= RunQueuedScan;
                EditorApplication.update += RunQueuedScan;
                return;
            }
            EditorApplication.update -= RunQueuedScan;
            _scanQueued = false;
            SessionState.SetBool(QueueKey, false);
            CleanupView.Language = _language;
            CleanupView.Scan();
            Repaint();
        }

        private void OnEnable()
        {
            if (_scanQueued || SessionState.GetBool(QueueKey, false)) QueueScan();
        }

        private void OnDisable()
        {
            EditorApplication.delayCall -= RunQueuedScan;
            EditorApplication.update -= RunQueuedScan;
        }

        private void OnDestroy()
        {
            SessionState.SetBool(QueueKey, false);
            if (_cleanup != null) DestroyImmediate(_cleanup);
            _cleanup = null;
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("Project Health Scanner (PHS)", EditorStyles.boldLabel);
            _language = GUILayout.Toolbar(_language, new[] { "日本語", "English" });
            EditorGUILayout.LabelField(T("現在インポートされているバージョン Ver", "Installed Version Ver") + CurrentVersion);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(T("お問い合わせ / Discord", "Support / Discord"))) Application.OpenURL("https://discord.gg/cpu6ZFRJE");
                if (GUILayout.Button(T("使い方", "How to"))) { CleanupView.Language = _language; CleanupView.Help(); }
            }
            if (_scanQueued) EditorGUILayout.HelpBox(T("調査を開始します。編集中のインポート等がある場合は完了を待ちます。", "Scan queued. Waiting for editor import/compilation or Play mode to finish."), MessageType.Info);
            CleanupView.Language = _language;
            int nextTab = GUILayout.Toolbar(_tab, new[] { T("不要ファイル整理", "Cleanup"), T("削除履歴・再インポート", "History / reimport") });
            if (nextTab != _tab) { _tab = nextTab; if (_tab == 1) CleanupView.LoadHistory(); }
            if (_tab == 0) CleanupView.DrawContent(); else CleanupView.DrawHistory();
        }
    }
}
