using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace ProjectHealthScanner
{
    internal sealed class HierarchyCleanupPlan
    {
        [Serializable] internal sealed class ReviewItem { public string category; public string path; public string detail; public long bytes; }
        public readonly List<ReviewItem> review = new List<ReviewItem>();
        public long totalAssetBytes;
        public long SelectedBytes(IEnumerable<string> selected) => selected.Distinct(StringComparer.OrdinalIgnoreCase)
            .Where(sizes.ContainsKey).Sum(p => sizes[p]);
        public readonly List<string> candidates = new List<string>();
        public readonly Dictionary<string, string> retained = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public readonly Dictionary<string, long> sizes = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        public readonly List<string> roots = new List<string>();
        public readonly List<string> referenceIssues = new List<string>();
        public readonly List<Object> issueObjects = new List<Object>();
        public bool savedSceneProtection;
        public readonly List<string> saveBlockers = new List<string>();
        public bool CanDelete => referenceIssues.Count == 0 || savedSceneProtection;
        public readonly List<string> protectedToolFolders = new List<string>();
    }

    [Serializable] internal sealed class CleanupBackupItem
    {
        public string path;
        public string guid;
        public string hash;
        public string metaHash;
        public bool attempted;
        public bool removed;
        public bool restored;
    }

    [Serializable] internal sealed class CleanupBackup
    {
        public int schema = 1;
        public string project;
        public string createdAt;
        public List<CleanupBackupItem> items = new List<CleanupBackupItem>();
        public List<CleanupBackupItem> folders = new List<CleanupBackupItem>();
    }

    internal static partial class HierarchyCleanup
    {
        internal static bool IsInternalPreviewScene(Scene scene) => EditorSceneManager.IsPreviewScene(scene) ||
            (!string.IsNullOrEmpty(scene.path) && AssetDatabase.AssetPathToGUID(scene.path) == "8cbd3f19cef3477439841053ced0661b");

        internal static bool ConfirmAndSaveScenes(Func<List<string>, bool> confirm, Func<Scene, bool> save)
        {
            var blockers = SaveBlockers();
            if (blockers.Count == 0) return true;
            if (!confirm(blockers)) return false;
            var pending = new List<Scene>();
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                var scene = SceneManager.GetSceneAt(i);
                if (scene.IsValid() && scene.isLoaded && !IsInternalPreviewScene(scene) &&
                    (string.IsNullOrEmpty(scene.path) || !File.Exists(scene.path) || scene.isDirty))
                    pending.Add(scene);
            }
            foreach (var scene in pending)
                if (!save(scene)) return false;
            return SaveBlockers().Count == 0;
        }

        internal static List<string> SaveBlockers()
        {
            var blockers = new List<string>();
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                var scene = SceneManager.GetSceneAt(i);
                if (!scene.IsValid() || !scene.isLoaded || IsInternalPreviewScene(scene)) continue;
                string reason = string.IsNullOrEmpty(scene.path) ? "未保存 / Unsaved" :
                    !File.Exists(scene.path) ? "保存ファイルなし / File missing" : scene.isDirty ? "変更あり / Modified" : null;
                if (reason != null) blockers.Add((string.IsNullOrEmpty(scene.path) ? scene.name : scene.path) + " — " + reason);
            }
            return blockers;
        }
        internal static string Project => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        internal static string BackupRoot => Path.Combine(Project, "ProjectHealthScannerBackups", "HierarchyCleanup");
        internal static long MeasureAssets(Func<string, float, bool> cancel = null)
        {
            long total = 0;
            int count = 0;
            foreach (string path in Directory.EnumerateFiles(Application.dataPath, "*", SearchOption.AllDirectories))
            {
                if (count++ % 250 == 0) Check(cancel, "Assets capacity: " + count, 0.95f);
                total = checked(total + new FileInfo(path).Length);
            }
            return total;
        }
        internal static string NewBackupDirectory() => Path.Combine(BackupRoot, DateTime.Now.ToString("yyyyMMdd-HHmmss-fffffff") + "-" + Guid.NewGuid().ToString("N").Substring(0, 8));
        internal static string BackupFile(string directory, string guid)
        {
            if (string.IsNullOrEmpty(guid) || !Regex.IsMatch(guid, @"\A[a-fA-F0-9]{32}\z")) throw new InvalidDataException("Invalid backup GUID.");
            return Path.Combine(directory, guid);
        }
        private static readonly HashSet<string> Extensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
            ".prefab", ".fbx", ".obj", ".dae", ".blend", ".3ds", ".dxf", ".max", ".ma", ".mb",
            ".mat", ".png", ".jpg", ".jpeg", ".tga", ".tif", ".tiff", ".bmp", ".psd", ".psb", ".exr", ".hdr", ".gif",
            ".controller", ".overridecontroller", ".anim", ".mask", ".wav", ".mp3", ".ogg", ".aif", ".aiff", ".flac",
            ".physicmaterial", ".physicsmaterial2d"
        };

        internal static bool Within(string path, string folder) => string.Equals(path, folder, StringComparison.OrdinalIgnoreCase) ||
            path.StartsWith(folder.TrimEnd('/') + "/", StringComparison.OrdinalIgnoreCase);

        // Keep the distribution boundary independent of the selected scan scope.
        internal static string DistributionRoot(string path)
        {
            if (!path.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase)) return "";
            int slash = path.IndexOf('/', 7);
            return slash < 0 ? "" : path.Substring(0, slash);
        }

        internal static void ClassifyFolders(IEnumerable<string> paths, out HashSet<string> tools, out HashSet<string> models)
        {
            tools = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            models = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var code = new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
                ".cs", ".dll", ".asmdef", ".asmref", ".js", ".boo", ".exe", ".so", ".dylib", ".bundle",
                ".shader", ".shadergraph", ".shadersubgraph", ".compute", ".cginc", ".hlsl"
            };
            var geometry = new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
                ".fbx", ".obj", ".dae", ".blend", ".3ds", ".dxf", ".max", ".ma", ".mb"
            };
            foreach (string path in paths)
            {
                string root = DistributionRoot(path);
                if (root.Length == 0) continue;
                if (DynamicOrTool(path) || code.Contains(Path.GetExtension(path)) ||
                    Path.GetFileName(path).Equals("package.json", StringComparison.OrdinalIgnoreCase)) tools.Add(root);
                if (geometry.Contains(Path.GetExtension(path))) models.Add(root);
            }
            models.ExceptWith(tools);
        }

        internal static bool DynamicOrTool(string path)
        {
            string p = "/" + path.Replace('\\', '/').ToLowerInvariant() + "/";
            return new[] { "/resources/", "/streamingassets/", "/plugins/", "/editor/", "/editor default resources/",
                "/gizmos/", "/addressableassetsdata/", "/mim/", "/vrcsdk/", "/vrchat sdk/" }.Any(p.Contains);
        }

        internal static bool Eligible(string path)
        {
            if (!path.StartsWith("Assets/", StringComparison.Ordinal) || DynamicOrTool(path)) return false;
            if (Extensions.Contains(Path.GetExtension(path))) return true;
            if (!path.EndsWith(".asset", StringComparison.OrdinalIgnoreCase)) return false;
            Type type = AssetDatabase.GetMainAssetTypeAtPath(path);
            return type != null && (typeof(Mesh).IsAssignableFrom(type) || typeof(Material).IsAssignableFrom(type) ||
                typeof(Texture).IsAssignableFrom(type) || typeof(AnimationClip).IsAssignableFrom(type) ||
                typeof(RuntimeAnimatorController).IsAssignableFrom(type) || typeof(Avatar).IsAssignableFrom(type) || typeof(AvatarMask).IsAssignableFrom(type));
        }

        private static void Check(Func<string, float, bool> cancel, string message, float fraction)
        {
            if (cancel != null && cancel(message, fraction)) throw new OperationCanceledException();
        }

        // Read IDs from live serialized objects; never recursively load asset contents.
        internal static void CollectLiveReferences(IEnumerable<Object> roots, Action<string> keep,
            Func<string, float, bool> cancel = null, Action<Object, string> unresolved = null)
        {
            var seen = new HashSet<int>();
            var queue = new Queue<Object>();
            foreach (var root in roots)
                if (root != null && seen.Add(root.GetInstanceID())) queue.Enqueue(root);
            int examined = 0;
            while (queue.Count > 0)
            {
                var obj = queue.Dequeue();
                if (obj == null) continue;
                string ownPath = AssetDatabase.GetAssetPath(obj.GetInstanceID());
                if (!string.IsNullOrEmpty(ownPath)) { keep(ownPath); continue; }
                if (obj is Texture || obj is Mesh || obj is AudioClip || obj is Shader) continue;
                Check(cancel, "Hierarchy references: " + obj.name, 0.2f);
                using (var serialized = new SerializedObject(obj))
                {
                    var property = serialized.GetIterator();
                    while (property.Next(true))
                    {
                        if (++examined % 512 == 0) Check(cancel, "Hierarchy references: " + obj.name, 0.2f);
                        if (property.propertyType != SerializedPropertyType.ObjectReference) continue;
                        int id = property.objectReferenceInstanceIDValue;
                        if (id == 0) continue;
                        string path = AssetDatabase.GetAssetPath(id);
                        if (!string.IsNullOrEmpty(path)) { keep(path); continue; }
                        if (seen.Contains(id)) continue;
                        // Resolve just this reference. Prefab components and lazy native references
                        // need not appear in an initial FindObjectsOfTypeAll snapshot.
                        var referenced = property.objectReferenceValue;
                        if (referenced == null)
                        {
                            if (unresolved == null) throw new InvalidOperationException("Reference could not be resolved: " + obj.name + "." + property.propertyPath);
                            unresolved(obj, property.propertyPath);
                            continue;
                        }
                        path = AssetDatabase.GetAssetPath(referenced);
                        if (string.IsNullOrEmpty(path) && referenced is Component component)
                            path = AssetDatabase.GetAssetPath(component.gameObject);
                        if (!string.IsNullOrEmpty(path)) { keep(path); continue; }
                        if (EditorUtility.IsPersistent(referenced))
                            throw new InvalidOperationException("参照先のファイルを特定できません。 / Cannot locate referenced asset: " + obj.name + "." + property.propertyPath);
                        seen.Add(id);
                        if (seen.Add(referenced.GetInstanceID()) || referenced.GetInstanceID() == id) queue.Enqueue(referenced);
                    }
                }
            }
        }

        internal static HierarchyCleanupPlan Scan(string scope, bool protectOtherScenes, IEnumerable<string> extraKeep,
            Func<string, float, bool> cancel = null)
        {
            scope = (scope ?? "").Replace('\\', '/').TrimEnd('/');
            if (!(scope == "Assets" || scope.StartsWith("Assets/", StringComparison.Ordinal)) || !AssetDatabase.IsValidFolder(scope))
                throw new InvalidOperationException("Assets内のフォルダを指定してください。 / Choose a folder inside Assets.");
            var result = new HierarchyCleanupPlan();
            var paths = AssetDatabase.GetAllAssetPaths().Where(p =>
                (p.StartsWith("Assets/", StringComparison.Ordinal) || p.StartsWith("Packages/", StringComparison.Ordinal)) && !AssetDatabase.IsValidFolder(p)).ToArray();
            var seeds = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            Action<string, string> keep = (path, reason) => {
                if (!string.IsNullOrEmpty(path) && !seeds.ContainsKey(path)) seeds.Add(path, reason);
            };
            var openScenes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var liveObjects = new List<Object>();
            var hierarchyAssets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                var scene = SceneManager.GetSceneAt(i);
                if (!scene.IsValid() || !scene.isLoaded) continue;
                openScenes.Add(scene.path);
                foreach (var root in scene.GetRootGameObjects())
                {
                    result.roots.Add(scene.name + "/" + root.name);
                    foreach (var transform in root.GetComponentsInChildren<Transform>(true))
                    {
                        Check(cancel, "Hierarchy: " + transform.name, 0.1f);
                        if (GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(transform.gameObject) > 0 ||
                            PrefabUtility.GetPrefabInstanceStatus(transform.gameObject) == PrefabInstanceStatus.MissingAsset)
                            throw new InvalidOperationException("Missing Script / Missing Prefabを先に修復してください。 / Repair missing scripts or prefabs first: " + transform.name);
                        liveObjects.Add(transform.gameObject);
                        liveObjects.AddRange(transform.GetComponents<Component>().Where(c => c != null));
                        keep(PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(transform.gameObject), "Hierarchy Prefab link");
                        string prefab = PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(transform.gameObject);
                        if (!string.IsNullOrEmpty(prefab)) hierarchyAssets.Add(prefab);
                    }
                }
            }
            if (result.roots.Count == 0) throw new InvalidOperationException("Hierarchyに残す対象がありません。 / No Hierarchy objects are loaded.");
            Check(cancel, "Hierarchy dependencies", 0.2f);
            CollectLiveReferences(liveObjects, path => { keep(path, "Hierarchy reference"); hierarchyAssets.Add(path); }, cancel, (obj, property) => {
                var component = obj as Component;
                string location = obj.name;
                if (component != null)
                {
                    var transform = component.transform;
                    location = transform.name;
                    while (transform.parent != null) { transform = transform.parent; location = transform.name + "/" + location; }
                    location = component.gameObject.scene.name + "/" + location + " (" + component.GetType().Name + ")";
                }
                result.referenceIssues.Add(location + "." + property);
                result.issueObjects.Add(obj);
            });

            // Unresolved references require a clean, saved representation. Preserve every
            // dependency and serialized GUID from those scenes, not just resolved live objects.
            if (result.referenceIssues.Count > 0)
            {
                result.saveBlockers.AddRange(SaveBlockers());
                if (result.saveBlockers.Count == 0)
                {
                    foreach (string scene in openScenes)
                    {
                        // Unity preview scenes may have no backing file. Their live references
                        // were already collected; only persisted scene data can be read here.
                        if (string.IsNullOrEmpty(scene) || !File.Exists(scene)) continue;
                        Check(cancel, "Protecting saved scene dependencies", 0.25f);
                        foreach (string dependency in AssetDatabase.GetDependencies(scene, true))
                            keep(dependency, "Saved scene fallback protection");
                        ReadGuids(scene, path => keep(path, "Saved scene GUID protection"));
                    }
                    result.savedSceneProtection = true;
                }
            }

            // The scene file itself is always kept.
            foreach (string scene in openScenes) result.retained[scene] = "Open scene";
            foreach (var buildScene in EditorBuildSettings.scenes)
                if (!openScenes.Contains(buildScene.path)) keep(buildScene.path, "Build Settings scene");
            foreach (var asset in PlayerSettings.GetPreloadedAssets()) keep(AssetDatabase.GetAssetPath(asset), "Preloaded asset");
            foreach (string extra in extraKeep ?? Enumerable.Empty<string>()) keep(extra, "Explicit keep");

            ClassifyFolders(paths, out var toolFolders, out var modelFolders);
            result.protectedToolFolders.AddRange(toolFolders.OrderBy(p => p));

            for (int i = 0; i < paths.Length; i++)
            {
                string path = paths[i];
                if (i % 50 == 0) Check(cancel, "Protecting configuration " + i + "/" + paths.Length, 0.3f);
                string distribution = DistributionRoot(path);
                if (toolFolders.Contains(distribution)) keep(path, "Tool distribution (including support assets)");
                else if (!modelFolders.Contains(distribution)) keep(path, "Unclassified distribution: retained");
                if (path.EndsWith(".unity", StringComparison.OrdinalIgnoreCase))
                {
                    result.retained[path] = "Scene file";
                    if (!openScenes.Contains(path) && (protectOtherScenes || !Within(path, scope))) keep(path, "Other saved scene");
                    continue;
                }
                if (!Within(path, scope)) keep(path, "Outside cleanup scope");
                else if (!Eligible(path)) keep(path, "Code / settings / dynamic assets");
                // Already protected files do not need another importer lookup just to keep them.
                if (!seeds.ContainsKey(path))
                {
                    var importer = AssetImporter.GetAtPath(path);
                    if (importer != null && !string.IsNullOrEmpty(importer.assetBundleName)) keep(path, "AssetBundle");
                }
            }
            // Protect GUID-based Addressables entries and folder entries without a dependency on its package API.
            foreach (string path in paths.Where(p => p.IndexOf("/AddressableAssetsData/", StringComparison.OrdinalIgnoreCase) >= 0 && p.EndsWith(".asset", StringComparison.OrdinalIgnoreCase)))
                ReadGuids(path, p => keep(p, "Addressables GUID"));
            foreach (string path in Directory.EnumerateFiles("ProjectSettings", "*.asset"))
                ReadGuids(path, p => keep(p, "Project setting"));

            var expanded = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var seed in seeds)
            {
                if (AssetDatabase.IsValidFolder(seed.Key))
                {
                    // Keep the folder GUID too, including empty folders referenced by live objects.
                    if (!expanded.ContainsKey(seed.Key)) expanded.Add(seed.Key, seed.Value);
                    foreach (string path in paths.Where(p => Within(p, seed.Key)))
                        if (!expanded.ContainsKey(path)) expanded.Add(path, seed.Value);
                }
                else if (!expanded.ContainsKey(seed.Key)) expanded.Add(seed.Key, seed.Value);
            }
            var queue = new Queue<string>();
            foreach (var seed in expanded)
            {
                result.retained[seed.Key] = seed.Value;
                if (!openScenes.Contains(seed.Key)) queue.Enqueue(seed.Key);
            }
            int n = 0;
            while (queue.Count > 0)
            {
                var batch = new List<string>(256);
                while (queue.Count > 0 && batch.Count < 256) batch.Add(queue.Dequeue());
                n += batch.Count;
                Check(cancel, "Following retained dependencies " + n, 0.6f);
                foreach (string dependency in AssetDatabase.GetDependencies(batch.ToArray(), false))
                    if (!result.retained.ContainsKey(dependency))
                    {
                        result.retained.Add(dependency, "Dependency of retained assets");
                        if (!openScenes.Contains(dependency)) queue.Enqueue(dependency);
                    }
            }
            foreach (string path in paths)
            {
                if (!Within(path, scope) || result.retained.ContainsKey(path) || !Eligible(path)) continue;
                // Missing metadata means GUID-based preservation cannot be trusted.
                if (!File.Exists(path + ".meta") || string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(path)))
                    throw new InvalidOperationException("Asset metadata is missing: " + path);
                result.candidates.Add(path);
                result.sizes[path] = new FileInfo(path).Length + new FileInfo(path + ".meta").Length;
            }
            result.totalAssetBytes = MeasureAssets(cancel);
            AddReview(result, paths, hierarchyAssets, cancel);
            result.candidates.Sort(StringComparer.OrdinalIgnoreCase);
            return result;
        }

        private static void AddReview(HierarchyCleanupPlan plan, string[] paths, HashSet<string> roots, Func<string, float, bool> cancel)
        {
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var rootPaths = roots.ToArray();
            for (int offset = 0; offset < rootPaths.Length; offset += 128)
            {
                Check(cancel, "Checking Hierarchy asset usage", 0.96f);
                foreach (string dependency in AssetDatabase.GetDependencies(rootPaths.Skip(offset).Take(128).ToArray(), true)) used.Add(dependency);
            }
            for (int i = 0; i < paths.Length; i++)
            {
                if (i % 100 == 0) Check(cancel, "Checking large assets " + i + "/" + paths.Length, 0.97f);
                string path = paths[i];
                if (!path.StartsWith("Assets/", StringComparison.Ordinal) || !File.Exists(path)) continue;
                long size = new FileInfo(path).Length;
                string ext = Path.GetExtension(path).ToLowerInvariant();
                string usage = used.Contains(path) ? "Hierarchy: 使用中 / Used" : "Hierarchy: 参照未検出 / No reference found";
                if (size > 50L * 1024 * 1024)
                    plan.review.Add(new HierarchyCleanupPlan.ReviewItem { category = "50MB超のアセット / Assets >50 MiB", path = path, bytes = size, detail = usage });
                if ((ext == ".psd" || ext == ".psb") && size > 100L * 1024 * 1024)
                    plan.review.Add(new HierarchyCleanupPlan.ReviewItem { category = "100MB超のPSD・PSB / PSD & PSB >100 MiB", path = path, bytes = size, detail = usage });
                if (ext == ".controller" || ext == ".overridecontroller")
                    plan.review.Add(new HierarchyCleanupPlan.ReviewItem { category = "Animator Controller", path = path, bytes = size, detail = usage + " / ファイル容量順に確認・処理負荷の実測ではありません / Disk size, not measured runtime cost" });
                var importer = AssetImporter.GetAtPath(path) as TextureImporter;
                if (importer == null) continue;
                importer.GetSourceTextureWidthAndHeight(out int width, out int height);
                int limit = importer.maxTextureSize;
                string platform = BuildPipeline.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget).ToString();
                if (platform == "iOS") platform = "iPhone";
                var settings = importer.GetPlatformTextureSettings(platform);
                if (settings.overridden) limit = settings.maxTextureSize;
                if (Math.Min(Math.Max(width, height), limit) >= 4096)
                    plan.review.Add(new HierarchyCleanupPlan.ReviewItem { category = "4K以上テクスチャ / Textures 4K+", path = path, bytes = size, detail = usage + $" / Source {width} × {height} / Max Size {limit} / インポート設定による判定 / Based on import settings" });
            }
            foreach (var package in UnityEditor.PackageManager.PackageInfo.GetAllRegisteredPackages())
            {
                if (package.source == UnityEditor.PackageManager.PackageSource.BuiltIn) continue;
                string prefix = "Packages/" + package.name + "/";
                bool referenced = used.Any(p => p.StartsWith(prefix, StringComparison.OrdinalIgnoreCase));
                plan.review.Add(new HierarchyCleanupPlan.ReviewItem { category = "Package参照 / Package references", path = prefix.TrimEnd('/'), bytes = 0,
                    detail = referenced ? "Hierarchy: 使用中 / Used" : "参照未検出（コード・SDK・依存Packageの利用は未判定、削除不可） / No asset reference; code/SDK/package use not determined. Not deletable here." });
            }
        }

        private static void ReadGuids(string filename, Action<string> found)
        {
            foreach (string line in File.ReadLines(filename))
                foreach (Match match in Regex.Matches(line, @"\b[a-fA-F0-9]{32}\b"))
                {
                    string path = AssetDatabase.GUIDToAssetPath(match.Value);
                    if (!string.IsNullOrEmpty(path)) found(path);
                }
        }

        internal static List<string> SelectionConflicts(HierarchyCleanupPlan plan, HashSet<string> selected)
        {
            var blocked = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string remaining in plan.candidates.Where(p => !selected.Contains(p)))
                foreach (string dependency in AssetDatabase.GetDependencies(remaining, true))
                    if (selected.Contains(dependency)) blocked.Add(dependency);
            return blocked.OrderBy(p => p).ToList();
        }

        internal static string Hash(string path)
        {
            using (var stream = File.OpenRead(path))
            using (var hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(stream)).Replace("-", "");
        }

        internal static string FullAssetPath(string root, string path)
        {
            if (string.IsNullOrEmpty(path) || !path.StartsWith("Assets/", StringComparison.Ordinal) || path.Contains("\\"))
                throw new InvalidDataException("Invalid asset path.");
            string full = Path.GetFullPath(Path.Combine(root, path));
            string prefix = Path.GetFullPath(Path.Combine(root, "Assets")) + Path.DirectorySeparatorChar;
            if (!full.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Asset path escapes project.");
            return full;
        }

        internal static void SaveBackup(string directory, CleanupBackup backup)
        {
            Directory.CreateDirectory(directory);
            string file = Path.Combine(directory, "manifest.json"), temp = file + ".tmp";
            string json = JsonUtility.ToJson(backup, true);
            for (int attempt = 0; ; attempt++)
            {
                try
                {
                    File.WriteAllText(temp, json, new UTF8Encoding(false));
                    if (File.Exists(file)) File.Replace(temp, file, null); else File.Move(temp, file);
                    return;
                }
                catch (IOException) when (attempt < 4) { System.Threading.Thread.Sleep(50); }
            }
        }

        internal static CleanupBackup ReadBackup(string directory)
        {
            var backup = JsonUtility.FromJson<CleanupBackup>(File.ReadAllText(Path.Combine(directory, "manifest.json")));
            if (backup == null || backup.schema != 1 || backup.items == null || !string.Equals(Project, backup.project, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Unsupported backup or different project path.");
            foreach (var item in backup.items) FullAssetPath(Project, item.path);
            if (backup.folders == null) backup.folders = new List<CleanupBackupItem>();
            foreach (var item in backup.folders) FullAssetPath(Project, item.path);
            return backup;
        }

        internal static List<string> EmptyFolders(string scope, IEnumerable<string> protectedPaths, bool allowAssetsScope = false)
        {
            if ((scope == "Assets" && !allowAssetsScope) || !AssetDatabase.IsValidFolder(scope))
                throw new InvalidOperationException("整理するフォルダを指定してください。 / Select a cleanup folder below Assets.");
            if (scope != "Assets") FullAssetPath(Project, scope);
            var keep = protectedPaths.ToArray();
            var empty = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var paths = AssetDatabase.GetAllAssetPaths();
            ClassifyFolders(paths, out var tools, out var models);
            foreach (string path in paths.Where(p => p == scope || p.StartsWith(scope + "/", StringComparison.Ordinal))
                .Where(p => p != "Assets" && AssetDatabase.IsValidFolder(p)).OrderByDescending(p => p.Length))
            {
                if (DynamicOrTool(path) || tools.Any(t => path == t || path.StartsWith(t + "/", StringComparison.OrdinalIgnoreCase)) ||
                    keep.Any(k => path == k || path.StartsWith(k + "/", StringComparison.OrdinalIgnoreCase) || k.StartsWith(path + "/", StringComparison.OrdinalIgnoreCase))) continue;
                string full = FullAssetPath(Project, path);
                if ((File.GetAttributes(full) & FileAttributes.ReparsePoint) != 0) continue;
                bool onlyEmptyChildren = Directory.EnumerateFileSystemEntries(full).All(entry =>
                {
                    string child = path + "/" + Path.GetFileName(entry);
                    return Directory.Exists(entry) ? empty.Contains(child) :
                        child.EndsWith(".meta", StringComparison.OrdinalIgnoreCase) && empty.Contains(child.Substring(0, child.Length - 5));
                });
                if (onlyEmptyChildren && File.Exists(full + ".meta")) empty.Add(path);
            }
            return empty.OrderByDescending(p => p.Length).ToList();
        }

        internal static int TrashEmptyFolders(string directory, IEnumerable<string> paths)
        {
            var backup = new CleanupBackup { project = Project, createdAt = DateTime.Now.ToString("O") };
            foreach (string path in paths.Distinct().OrderByDescending(p => p.Length))
            {
                string full = FullAssetPath(Project, path);
                string guid = AssetDatabase.AssetPathToGUID(path);
                string destination = BackupFile(directory, guid) + ".meta";
                Directory.CreateDirectory(Path.GetDirectoryName(destination));
                File.Copy(full + ".meta", destination, false);
                string hash = Hash(full + ".meta");
                if (Hash(destination) != hash) throw new IOException("Folder backup verification failed: " + path);
                backup.folders.Add(new CleanupBackupItem { path = path, guid = guid, metaHash = hash });
            }
            SaveBackup(directory, backup);
            try
            {
                foreach (var folder in backup.folders)
                {
                    string full = FullAssetPath(Project, folder.path);
                    if ((File.GetAttributes(full) & FileAttributes.ReparsePoint) != 0 || Directory.EnumerateFileSystemEntries(full).Any() || Hash(full + ".meta") != folder.metaHash)
                        throw new IOException("Folder is no longer empty or changed: " + folder.path);
                    folder.attempted = true;
                    SaveBackup(directory, backup);
                    if (!AssetDatabase.MoveAssetToTrash(folder.path)) throw new IOException("Could not remove folder: " + folder.path);
                }
            }
            catch
            {
                Restore(directory, backup, new List<string>());
                throw;
            }
            return backup.folders.Count;
        }

        internal static CleanupBackup Backup(string directory, IEnumerable<string> selected, Func<string, float, bool> cancel = null)
        {
            if (Directory.Exists(directory)) throw new IOException("Backup destination already exists.");
            var backup = new CleanupBackup { project = Project, createdAt = DateTime.Now.ToString("O") };
            string[] paths = selected.Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(p => p).ToArray();
            for (int i = 0; i < paths.Length; i++)
            {
                Check(cancel, "Backup: " + paths[i], (float)i / Math.Max(1, paths.Length));
                string source = FullAssetPath(Project, paths[i]);
                string guid = AssetDatabase.AssetPathToGUID(paths[i]);
                string destination = BackupFile(directory, guid);
                if (!Eligible(paths[i]) || !File.Exists(source + ".meta")) throw new InvalidOperationException("Asset cannot be backed up: " + paths[i]);
                Directory.CreateDirectory(Path.GetDirectoryName(destination));
                File.Copy(source, destination, false);
                File.Copy(source + ".meta", destination + ".meta", false);
                string hash = Hash(source), metaHash = Hash(source + ".meta");
                if (Hash(destination) != hash || Hash(destination + ".meta") != metaHash) throw new IOException("Backup verification failed: " + paths[i]);
                backup.items.Add(new CleanupBackupItem { path = paths[i], guid = guid, hash = hash, metaHash = metaHash });
            }
            SaveBackup(directory, backup);
            return backup;
        }

        internal static int Trash(string directory, CleanupBackup backup, Func<string, float, bool> cancel, List<string> failed,
            string scope = "Assets", IEnumerable<string> protectedPaths = null)
        {
            // Include pre-existing empty folders in scope, with the same protection and backup.
            var parents = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            ClassifyFolders(AssetDatabase.GetAllAssetPaths(), out var tools, out var models);
            var keep = (protectedPaths ?? Enumerable.Empty<string>()).Concat(tools).ToArray();
            parents.UnionWith(EmptyFolders(scope, keep, true));
            foreach (var item in backup.items)
            {
                string parent = item.path.Substring(0, item.path.LastIndexOf('/'));
                while (parent != "Assets" && (parent == scope || parent.StartsWith(scope + "/", StringComparison.Ordinal)))
                {
                    string full = FullAssetPath(Project, parent);
                    if (DynamicOrTool(parent) || keep.Any(k => parent == k || parent.StartsWith(k + "/", StringComparison.OrdinalIgnoreCase) || k.StartsWith(parent + "/", StringComparison.OrdinalIgnoreCase)) ||
                        (File.GetAttributes(full) & FileAttributes.ReparsePoint) != 0) break;
                    parents.Add(parent);
                    parent = parent.Substring(0, parent.LastIndexOf('/'));
                }
            }
            // Validate every source before the first move. The caller also revalidates Hierarchy dependencies.
            foreach (var item in backup.items)
                if (!Eligible(item.path) || AssetDatabase.AssetPathToGUID(item.path) != item.guid ||
                    Hash(FullAssetPath(Project, item.path)) != item.hash || Hash(FullAssetPath(Project, item.path) + ".meta") != item.metaHash ||
                    Hash(BackupFile(directory, item.guid)) != item.hash || Hash(BackupFile(directory, item.guid) + ".meta") != item.metaHash)
                    throw new IOException("Asset changed after backup: " + item.path);
            int count = 0;
            try
            {
                for (int i = 0; i < backup.items.Count; i++)
                {
                    var item = backup.items[i];
                    if (cancel != null && cancel("Trash: " + item.path, (float)i / Math.Max(1, backup.items.Count)))
                        throw new OperationCanceledException();
                    if (Hash(FullAssetPath(Project, item.path)) != item.hash || Hash(FullAssetPath(Project, item.path) + ".meta") != item.metaHash)
                        throw new IOException("Asset changed during cleanup: " + item.path);
                    item.attempted = true;
                    SaveBackup(directory, backup);
                    if (!AssetDatabase.MoveAssetToTrash(item.path))
                    { failed.Add(item.path); throw new IOException("Could not move asset to trash: " + item.path); }
                    item.removed = true;
                    count++;
                }
                foreach (string path in parents.OrderByDescending(p => p.Length))
                {
                    Check(cancel, "Empty folder: " + path, 1f);
                    string full = FullAssetPath(Project, path);
                    if (!Directory.Exists(full) || Directory.EnumerateFileSystemEntries(full).Any()) continue;
                    if ((File.GetAttributes(full) & FileAttributes.ReparsePoint) != 0) continue;
                    string guid = AssetDatabase.AssetPathToGUID(path);
                    string source = full + ".meta", destination = BackupFile(directory, guid) + ".meta";
                    Directory.CreateDirectory(Path.GetDirectoryName(destination));
                    File.Copy(source, destination, false);
                    string hash = Hash(source);
                    if (Hash(destination) != hash) throw new IOException("Folder backup verification failed: " + path);
                    var folder = new CleanupBackupItem { path = path, guid = guid, metaHash = hash, attempted = true };
                    backup.folders.Add(folder);
                    SaveBackup(directory, backup);
                    if (Directory.EnumerateFileSystemEntries(full).Any() || Hash(source) != hash)
                        throw new IOException("Folder changed during cleanup: " + path);
                    if (!AssetDatabase.MoveAssetToTrash(path)) throw new IOException("Could not remove empty folder: " + path);
                    folder.removed = true;
                }
            }
            catch
            {
                // A partial outfit deletion could break the remaining prefab. Roll back interrupted batches.
                var conflicts = new List<string>();
                Restore(directory, backup, conflicts);
                if (conflicts.Count > 0) throw new IOException("Automatic restoration left conflicts. Restore from backup: " + directory);
                throw;
            }
            finally { SaveBackup(directory, backup); WriteHistorySafely(directory, backup); }
            return count;
        }

        internal static int Restore(string directory, CleanupBackup backup, List<string> conflicts)
        {
            int count = 0;
            int journal = 0;
            Action checkpoint = () => { if (++journal % 50 == 0) SaveBackup(directory, backup); };
            try
            {
            foreach (var folder in (backup.folders ?? new List<CleanupBackupItem>()).Where(f => f.attempted && !f.restored).OrderBy(f => f.path.Length))
            {
                string full = FullAssetPath(Project, folder.path), source = BackupFile(directory, folder.guid) + ".meta";
                string current = AssetDatabase.GUIDToAssetPath(folder.guid);
                if (File.Exists(full) || (File.Exists(full + ".meta") && Hash(full + ".meta") != folder.metaHash) ||
                    (!string.IsNullOrEmpty(current) && current != folder.path)) { conflicts.Add(folder.path); continue; }
                if (Hash(source) != folder.metaHash) throw new IOException("Folder backup checksum mismatch: " + folder.path);
                Directory.CreateDirectory(full);
                if (!File.Exists(full + ".meta")) File.Copy(source, full + ".meta", false);
                folder.restored = true; count++; checkpoint();
            }
            foreach (var item in backup.items.Where(i => i.attempted && !i.restored))
            {
                string destination = FullAssetPath(Project, item.path), source = BackupFile(directory, item.guid);
                string currentPath = AssetDatabase.GUIDToAssetPath(item.guid);
                bool hasFile = File.Exists(destination), hasMeta = File.Exists(destination + ".meta");
                if ((hasFile && Hash(destination) != item.hash) || (hasMeta && Hash(destination + ".meta") != item.metaHash) ||
                    (!string.IsNullOrEmpty(currentPath) && !string.Equals(currentPath, item.path, StringComparison.OrdinalIgnoreCase)))
                {
                    conflicts.Add(item.path);
                    continue;
                }
                if (hasFile && hasMeta) { item.restored = true; checkpoint(); continue; }
                if (Hash(source) != item.hash || Hash(source + ".meta") != item.metaHash) throw new IOException("Backup checksum mismatch: " + item.path);
                Directory.CreateDirectory(Path.GetDirectoryName(destination));
                if (!hasFile) File.Copy(source, destination, false);
                if (!hasMeta) File.Copy(source + ".meta", destination + ".meta", false);
                item.restored = true;
                checkpoint();
                count++;
            }
            }
            finally
            {
                SaveBackup(directory, backup);
                WriteHistorySafely(directory, backup);
                AssetDatabase.Refresh();
            }
            return count;
        }
    }

    public sealed partial class ProjectHealthHierarchyCleanupWindow : EditorWindow
    {
        internal EditorWindow Host;
        internal int Language { get => _language; set => _language = value; }
        [SerializeField] private DefaultAsset _scope;
        [SerializeField] private bool _otherScenes = true;
        [SerializeField] private List<Object> _extraKeep = new List<Object>();
        [SerializeField] private int _language;
        private HierarchyCleanupPlan _plan;
        private readonly HashSet<string> _selected = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _expanded = new HashSet<string>();
        private Vector2 _scroll;
        [SerializeField] private string _status = "";
        [SerializeField] private MessageType _statusType = MessageType.Info;
        private string _latestBackup;
        private string _backupError;
        private bool _showKeep;
        private bool _showReview;
        private int _reviewOrder;
        private bool _sizeOrder = true;
        [SerializeField] private bool _hasDeletionResult;
        [SerializeField] private long _beforeDeletionBytes;
        [SerializeField] private long _afterDeletionBytes;
        private string T(string jp, string en) => _language == 0 ? jp : en;
        private string Scope => _scope != null ? AssetDatabase.GetAssetPath(_scope) : "Assets";
        private string[] Extra => _extraKeep.Where(o => o != null).Select(AssetDatabase.GetAssetPath).Where(p => !string.IsNullOrEmpty(p)).ToArray();

        public static void Open()
        {
            ProjectHealthScannerWindow.Open();
        }

        public static void OpenAndScan() => ProjectHealthScannerWindow.Open();

        private void OnEnable() { RefreshBackups(); }
        internal void RefreshBackups()
        {
            _latestBackup = null; _backupError = null;
            try
            {
                if (!Directory.Exists(HierarchyCleanup.BackupRoot)) return;
                foreach (string directory in Directory.GetDirectories(HierarchyCleanup.BackupRoot).OrderByDescending(p => p, StringComparer.Ordinal))
                {
                    if (!File.Exists(Path.Combine(directory, "manifest.json"))) continue;
                    var backup = HierarchyCleanup.ReadBackup(directory);
                    if (backup.items.Concat(backup.folders).Any(i => i.attempted && !i.restored)) { _latestBackup = directory; break; }
                }
            }
            catch (Exception ex) { _backupError = ex.Message; }
        }

        private void OnGUI()
        {
            EditorGUILayout.HelpBox("PHSを開いて不要ファイルを調べます。 / Open PHS to scan unused files.", MessageType.Info);
            if (GUILayout.Button("Project Health Scanner")) { Open(); Close(); }
        }

        internal void DrawContent()
        {
            EditorGUILayout.HelpBox(T("開いている全シーンのHierarchyを残す基準にします。非アクティブの衣装・オブジェクトも含みます。", "All loaded scene Hierarchies are retained, including inactive clothes and objects."), MessageType.Info);
            EditorGUI.BeginChangeCheck();
            _scope = (DefaultAsset)EditorGUILayout.ObjectField(T("整理するフォルダ（空欄はAssets）", "Cleanup folder (empty = Assets)"), _scope, typeof(DefaultAsset), false);
            _otherScenes = EditorGUILayout.ToggleLeft(T("開いていない保存済みシーンの参照も残す", "Also protect references from other saved scenes"), _otherScenes);
            if (!_otherScenes) EditorGUILayout.HelpBox(T("未ロードのシーン・保管Prefabだけが使うファイルも候補になります。Build Settingsのシーンは保護します。", "Files used only by unloaded scenes or stored prefabs can be candidates. Build Settings scenes are protected."), MessageType.Warning);
            _showKeep = EditorGUILayout.Foldout(_showKeep, T("追加で残すファイル・フォルダ", "Additional files/folders to keep"), true);
            if (_showKeep)
            {
                for (int i = 0; i < _extraKeep.Count; i++)
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        _extraKeep[i] = EditorGUILayout.ObjectField(_extraKeep[i], typeof(Object), false);
                        if (GUILayout.Button("−", GUILayout.Width(26))) { _extraKeep.RemoveAt(i); break; }
                    }
                if (GUILayout.Button(T("残す対象を追加", "Add retained asset/folder"))) _extraKeep.Add(null);
            }
            if (EditorGUI.EndChangeCheck()) { _plan = null; _selected.Clear(); _hasDeletionResult = false; }
            bool pending = Host is ProjectHealthScannerWindow host && host.ScanPending;
            bool busy = pending || EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode;
            using (new EditorGUI.DisabledScope(busy))
                if (GUILayout.Button(pending ? T("スキャン開始待ち…（追加操作は不要）", "Scan queued — no additional click needed") :
                    _plan == null ? T("スキャンを開始", "Start scan") : T("変更後に再スキャン", "Rescan after changes"), GUILayout.Height(28))) { Scan(); GUIUtility.ExitGUI(); }

            if (!string.IsNullOrEmpty(_status)) EditorGUILayout.HelpBox(_status, _statusType);
            else if (_plan == null && !_hasDeletionResult && !pending)
                EditorGUILayout.HelpBox(T("未スキャンです。上のボタンで調査を開始してください。", "Not scanned yet. Start using the button above."), MessageType.Info);

            if (_plan != null)
            {
                EditorGUILayout.HelpBox(T($"ツール関連 {_plan.protectedToolFolders.Count} フォルダを保護。モデルを含む配布フォルダだけを候補範囲にしています。用途不明・ツール混在フォルダは残します。", $"Protected {_plan.protectedToolFolders.Count} tool folders. Only distributions containing models are considered. Unknown and mixed tool folders are retained."), MessageType.Info);
                EditorGUILayout.LabelField(T($"Hierarchyルート {_plan.roots.Count} / 削除候補 {_plan.candidates.Count}ファイル / {Bytes(_plan.sizes.Values.Sum())}",
                    $"{_plan.roots.Count} Hierarchy roots / {_plan.candidates.Count} candidate files / {Bytes(_plan.sizes.Values.Sum())}"));
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button(T("候補をすべて選択", "Select all candidates"))) foreach (string path in _plan.candidates) _selected.Add(path);
                    if (GUILayout.Button(T("選択解除", "Clear"))) _selected.Clear();
                    if (GUILayout.Button(T("調査結果JSON", "Export report JSON"))) Export();
                }
                DrawCapacity(_plan.totalAssetBytes, Math.Max(0, _plan.totalAssetBytes - _plan.SelectedBytes(_selected)), false);
            }
            else if (_hasDeletionResult) DrawCapacity(_beforeDeletionBytes, _afterDeletionBytes, true);
            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            if (_plan != null)
            {
                _sizeOrder = EditorGUILayout.ToggleLeft(T("サイズの大きい順", "Largest files first"), _sizeOrder);
                _showReview = EditorGUILayout.Foldout(_showReview, T($"確認項目（Package・Controller・大容量ファイル） {_plan.review.Count}件", $"Review packages, controllers and large assets ({_plan.review.Count})"), true);
                if (_showReview)
                {
                    EditorGUILayout.HelpBox(T("使用状況はロード済みHierarchyとPrefab・アニメーション等の依存先が基準です。参照未検出でも未使用とは限りません。確認項目は削除候補とは別です。", "Usage follows loaded Hierarchy asset dependencies. No reference does not prove unused. Review items are separate from deletion candidates."), MessageType.Info);
                    _reviewOrder = GUILayout.Toolbar(_reviewOrder, new[] { T("優先度順", "Priority"), T("サイズ順", "Size") });
                    EditorGUILayout.LabelField(T("優先度：大容量PSD/PSB → 大容量Asset → 4K → Controller → Package", "Priority: large PSD/PSB, large assets, 4K, controllers, packages"), EditorStyles.wordWrappedMiniLabel);
                    var orderedReview = _reviewOrder == 1
                        ? _plan.review.OrderByDescending(r => r.bytes)
                        : _plan.review.OrderBy(r => r.category.StartsWith("100") ? 0 : r.category.StartsWith("50") ? 1 : r.category.StartsWith("4K") ? 2 : r.category.StartsWith("Animator") ? 3 : 4).ThenByDescending(r => r.bytes);
                    foreach (var section in orderedReview.GroupBy(r => _reviewOrder == 1 ? T("全確認項目", "All review items") : r.category))
                    {
                        EditorGUILayout.LabelField(section.Key, EditorStyles.boldLabel);
                        foreach (var item in section.OrderByDescending(r => r.bytes).ThenBy(r => r.path))
                        {
                            EditorGUILayout.LabelField(item.path + (item.bytes > 0 ? "  " + Bytes(item.bytes) : ""), EditorStyles.wordWrappedLabel);
                            EditorGUILayout.LabelField((_reviewOrder == 1 ? item.category + " / " : "") + item.detail, EditorStyles.wordWrappedMiniLabel);
                        }
                    }
                }
                if (_plan.referenceIssues.Count > 0)
                {
                    if (_plan.saveBlockers.Count > 0)
                        EditorGUILayout.HelpBox(T("保存が必要なシーン：\n", "Scenes requiring a save:\n") + string.Join("\n", _plan.saveBlockers), MessageType.Warning);
                    EditorGUILayout.HelpBox(_plan.savedSceneProtection
                        ? T("参照切れは残っていますが、保存済みシーンの依存先も保護しました。候補の削除は可能です。参照切れ自体は修復しません。", "Unresolved references remain. Saved-scene dependencies are protected, allowing candidate removal. Missing references are not repaired.")
                        : T("参照切れがあります。開いているシーンを保存して再スキャンしてください。保存済みデータを使って追加保護するまで削除できません。", "Unresolved references: save all loaded scenes and scan again to enable saved-scene protection before removal."), MessageType.Warning);
                    for (int i = 0; i < _plan.referenceIssues.Count; i++)
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            EditorGUILayout.LabelField(new GUIContent(_plan.referenceIssues[i], _plan.referenceIssues[i]), EditorStyles.wordWrappedMiniLabel);
                            if (GUILayout.Button(T("対象を選択", "Select object"), GUILayout.Width(90)))
                            {
                                var target = _plan.issueObjects[i];
                                Selection.activeObject = target is Component c ? c.gameObject : target;
                                EditorGUIUtility.PingObject(Selection.activeObject);
                            }
                        }
                }
                if (_plan.candidates.Count == 0) EditorGUILayout.HelpBox(T("この範囲に削除候補はありません。", "No cleanup candidates in this scope."), MessageType.Info);
                foreach (var group in _plan.candidates.GroupBy(Group).OrderByDescending(g => _sizeOrder ? g.Sum(p => _plan.sizes[p]) : 0).ThenBy(g => g.Key))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        bool all = group.All(_selected.Contains);
                        bool next = EditorGUILayout.Toggle(all, GUILayout.Width(18));
                        if (next != all) foreach (string path in group) { if (next) _selected.Add(path); else _selected.Remove(path); }
                        bool expanded = EditorGUILayout.Foldout(_expanded.Contains(group.Key), group.Key + $" ({group.Count()})  " + Bytes(group.Sum(p => _plan.sizes[p])), true);
                        if (expanded) _expanded.Add(group.Key); else _expanded.Remove(group.Key);
                    }
                    if (!_expanded.Contains(group.Key)) continue;
                    foreach (string path in group.OrderByDescending(p => _sizeOrder ? _plan.sizes[p] : 0).ThenBy(p => p))
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            bool selected = EditorGUILayout.Toggle(_selected.Contains(path), GUILayout.Width(18));
                            if (selected) _selected.Add(path); else _selected.Remove(path);
                            EditorGUILayout.LabelField(new GUIContent(path, path), EditorStyles.miniLabel);
                            GUILayout.Label(Bytes(_plan.sizes[path]), GUILayout.Width(75));
                            if (GUILayout.Button(T("表示", "Show"), GUILayout.Width(45))) EditorGUIUtility.PingObject(AssetDatabase.LoadMainAssetAtPath(path));
                        }
                }
            }
            EditorGUILayout.EndScrollView();
            EditorGUILayout.LabelField(T("コード・SDK・動的ロード用フォルダ・不明な設定アセットは保護します。", "Code, SDKs, dynamic-load folders and unknown configuration assets are protected."), EditorStyles.miniLabel);
            using (new EditorGUI.DisabledScope(busy || _selected.Count == 0 || _plan == null || !_plan.CanDelete || _backupError != null))
                if (GUILayout.Button(T($"選択した{_selected.Count}ファイルをバックアップして削除", $"Back up and remove {_selected.Count} selected files"), GUILayout.Height(30))) Delete();
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(busy || _latestBackup == null || _backupError != null))
                    if (GUILayout.Button(T("最新の削除を復元", "Restore latest cleanup"))) Restore();
                if (GUILayout.Button(T("バックアップを再確認", "Refresh backups"))) RefreshBackups();
                using (new EditorGUI.DisabledScope(!Directory.Exists(HierarchyCleanup.BackupRoot)))
                    if (GUILayout.Button(T("保存先を開く", "Open backup folder"))) EditorUtility.RevealInFinder(HierarchyCleanup.BackupRoot);
            }
            if (_backupError != null) EditorGUILayout.HelpBox(_backupError, MessageType.Error);
        }

        private string Group(string path)
        {
            string prefix = Scope.TrimEnd('/') + "/";
            string relative = path.Substring(prefix.Length);
            int split = relative.IndexOf('/');
            return split < 0 ? Scope : prefix + relative.Substring(0, split);
        }
        private bool Progress(string message, float fraction) => EditorUtility.DisplayCancelableProgressBar("Hierarchy Cleanup", message, fraction);
        internal void Scan()
        {
            _plan = null; _selected.Clear(); _status = ""; _statusType = MessageType.Info; _hasDeletionResult = false;
            string failure = null;
            Debug.Log("[Project Health Scanner] Hierarchy scan started: " + Scope);
            try
            {
                if (!ConfirmSaveForScan()) return;
                _plan = HierarchyCleanup.Scan(Scope, _otherScenes, Extra, Progress);
                _status = T($"調査完了：削除候補 {_plan.candidates.Count} 件。下のフォルダを展開して確認してください。",
                    $"Scan complete: {_plan.candidates.Count} candidates. Expand the folders below to review.");
                if (_plan.candidates.Count == 0) _status = T("調査完了：削除候補は0件です。整理フォルダと保存済みシーンの保護設定を確認してください。", "Scan complete: no candidates. Check the cleanup folder and protection of saved scenes.");
                if (!_plan.CanDelete)
                {
                    _statusType = MessageType.Warning;
                    _status = T($"参照切れ {_plan.referenceIssues.Count} 件。シーンを保存して再スキャンしてください。削除は無効です。", $"{_plan.referenceIssues.Count} unresolved references. Save scenes and scan again. Removal is disabled.");
                }
                else if (_plan.savedSceneProtection) _status = T($"調査完了：参照切れ {_plan.referenceIssues.Count} 件は追加保護で対応済み。候補を選んで削除できます。", $"Scan complete. Saved-scene protection covers {_plan.referenceIssues.Count} unresolved references. Candidates can be selected for removal.");
                Debug.Log("[Project Health Scanner] " + _status);
                _scroll = Vector2.zero;
            }
            catch (OperationCanceledException) { _status = T("調査を中止しました。", "Scan cancelled."); }
            catch (Exception ex)
            {
                _statusType = MessageType.Error;
                failure = _status = T("調査に失敗しました。ファイルは削除していません。\n", "Scan failed. No files were removed.\n") + ex.Message;
                Debug.LogException(ex);
            }
            finally { EditorUtility.ClearProgressBar(); Repaint(); if (Host != null) Host.Repaint(); }
            if (failure != null) EditorUtility.DisplayDialog(T("スキャン失敗", "Scan failed"), failure, "OK");
        }

        private bool ConfirmSaveForScan()
        {
            EditorUtility.ClearProgressBar();
            bool ready = HierarchyCleanup.ConfirmAndSaveScenes(
                blockers => EditorUtility.DisplayDialog(T("シーンを保存", "Save scenes"),
                    T("シーンを保存してスキャンしますか？\n承認すると、以下のシーンの変更を保存します。\n\n", "Save scenes before scanning?\nApproving saves changes to these scenes.\n\n") + string.Join("\n", blockers),
                    T("保存してスキャン", "Save and scan"), T("キャンセル", "Cancel")),
                scene =>
                {
                    string path = scene.path;
                    if (string.IsNullOrEmpty(path))
                        path = EditorUtility.SaveFilePanelInProject(T("シーンの保存先", "Save scene as"),
                            string.IsNullOrEmpty(scene.name) ? "Scene" : scene.name, "unity",
                            T("シーンの保存先を選択してください。", "Choose where to save the scene."));
                    return !string.IsNullOrEmpty(path) && EditorSceneManager.SaveScene(scene, path);
                });
            if (!ready)
            {
                _statusType = MessageType.Warning;
                _status = T("保存が完了していないため、スキャン・削除を中止しました。", "Saving was not completed. Scanning and removal were stopped.");
            }
            return ready;
        }

        private bool ValidateSelection(out HierarchyCleanupPlan fresh)
        {
            fresh = null;
            if (!ConfirmSaveForScan()) return false;
            fresh = HierarchyCleanup.Scan(Scope, _otherScenes, Extra, Progress);
            if (!fresh.CanDelete)
            {
                _plan = fresh; _statusType = MessageType.Warning;
                _status = T("次のシーンを保存して再スキャンしてください：\n", "Save these scenes and scan again:\n") + string.Join("\n", fresh.saveBlockers);
                return false;
            }
            var candidates = new HashSet<string>(fresh.candidates, StringComparer.OrdinalIgnoreCase);
            if (_selected.Any(p => !candidates.Contains(p)))
            { _status = T("使用状況が変わりました。再調査して選び直してください。", "References changed. Scan and select again."); return false; }
            var conflicts = HierarchyCleanup.SelectionConflicts(fresh, _selected);
            if (conflicts.Count == 0) return true;
            _status = T("未選択の候補が使う素材が含まれています。同じ衣装の候補をまとめて選ぶか、この素材を選択解除してください。\n", "Unselected candidates depend on selected assets. Select the complete unused outfit or deselect these dependencies.\n") + string.Join("\n", conflicts.Take(5));
            return false;
        }

        private void Delete()
        {
            try
            {
                if (!ValidateSelection(out var fresh)) return;
                EditorUtility.ClearProgressBar();
                string preview = string.Join("\n", _selected.OrderBy(p => p).Take(10));
                preview = T($"削除前 Assets {GB(fresh.totalAssetBytes)} → 削除後予測 {GB(Math.Max(0, fresh.totalAssetBytes - fresh.SelectedBytes(_selected)))}\n\n",
                    $"Assets before {GB(fresh.totalAssetBytes)} → estimated after {GB(Math.Max(0, fresh.totalAssetBytes - fresh.SelectedBytes(_selected)))}\n\n") + preview;
                if (!EditorUtility.DisplayDialog(T("不要ファイルを削除", "Remove unused files"),
                    T($"{_selected.Count}ファイル / {Bytes(_selected.Sum(p => fresh.sizes[p]))}\n\nファイルと.metaをAssets外へバックアップし、OSのごみ箱へ移動します。整理範囲内に以前から残っている空フォルダと、今回空になった親フォルダも、同じバックアップに保存して削除します。\n動的ロード等、調査できない利用があるファイルは選択解除してください。\n\n", $"{_selected.Count} files / {Bytes(_selected.Sum(p => fresh.sizes[p]))}\n\nFiles and .meta files are copied to a backup outside Assets, then moved to the OS trash. Existing empty folders within the cleanup scope and newly emptied parent folders are removed with the same backup. Deselect files used through untracked dynamic loading.\n\n") + preview,
                    T("バックアップして削除", "Back up and remove"), T("キャンセル", "Cancel"))) return;
                string directory = HierarchyCleanup.NewBackupDirectory();
                var backup = HierarchyCleanup.Backup(directory, _selected, Progress);
                // A backup can take time; re-read the live references before any destructive step.
                if (!ValidateSelection(out fresh)) return;
                var failed = new List<string>();
                long before = fresh.totalAssetBytes;
                int count = HierarchyCleanup.Trash(directory, backup, Progress, failed, Scope, fresh.retained.Keys.Concat(Extra));
                _status = T($"削除 {count}ファイル / 失敗 {failed.Count}ファイル。バックアップから復元できます。", $"Removed {count} files / failed {failed.Count}. A restorable backup is available.");
                _status += T($" 空フォルダ {backup.folders.Count}個も整理しました。", $" Also removed {backup.folders.Count} empty folders.");
                _plan = null; _selected.Clear();
                _beforeDeletionBytes = before;
                _hasDeletionResult = false;
                try { _afterDeletionBytes = HierarchyCleanup.MeasureAssets(); _hasDeletionResult = true; }
                catch (Exception ex) { _status += "\n" + T("削除後の容量計測に失敗: ", "Post-cleanup measurement failed: ") + ex.Message; }
            }
            catch (OperationCanceledException) { _status = T("中止しました。削除前のバックアップは保持されます。", "Cancelled. Any created backup is retained."); }
            catch (Exception ex) { _status = ex.Message; _plan = null; _selected.Clear(); }
            finally { EditorUtility.ClearProgressBar(); RefreshBackups(); }
        }

        private void Restore()
        {
            try
            {
                var backup = HierarchyCleanup.ReadBackup(_latestBackup);
                if (!EditorUtility.DisplayDialog(T("削除したファイルを復元", "Restore removed files"), backup.createdAt + "\n" +
                    T("元のパスへ.metaと一緒に戻します。既存ファイルは上書きしません。", "Restore files and .meta files to their original paths without overwriting existing files."), T("復元", "Restore"), T("キャンセル", "Cancel"))) return;
                var conflicts = new List<string>();
                int count = HierarchyCleanup.Restore(_latestBackup, backup, conflicts);
                _status = T($"復元 {count}件 / 保留 {conflicts.Count}件", $"Restored {count} items / pending {conflicts.Count}") +
                    (conflicts.Count > 0 ? "\n" + string.Join("\n", conflicts.Take(5)) : "");
                _plan = null; _selected.Clear();
                _hasDeletionResult = false;
            }
            catch (Exception ex) { _status = ex.Message; }
            finally { RefreshBackups(); }
        }

        [Serializable] private sealed class ExportReport { public string scope; public bool protectOtherScenes; public string[] roots; public string[] candidates; public string[] retained; public HierarchyCleanupPlan.ReviewItem[] review;
            public bool removalAllowed; public string[] referenceIssues; public long totalAssetsBytes; public long selectedRemovalBytes; public long estimatedRemainingBytes; public string[] selected; }
        private void Export()
        {
            string path = EditorUtility.SaveFilePanel("Hierarchy Cleanup Report", HierarchyCleanup.Project, "HierarchyCleanup-" + DateTime.Now.ToString("yyyyMMdd-HHmmss"), "json");
            if (string.IsNullOrEmpty(path)) return;
            File.WriteAllText(path, JsonUtility.ToJson(new ExportReport { scope = Scope, protectOtherScenes = _otherScenes,
                review = _plan.review.ToArray(), removalAllowed = _plan.CanDelete, referenceIssues = _plan.referenceIssues.ToArray(), totalAssetsBytes = _plan.totalAssetBytes, selectedRemovalBytes = _plan.SelectedBytes(_selected),
                estimatedRemainingBytes = Math.Max(0, _plan.totalAssetBytes - _plan.SelectedBytes(_selected)), selected = _selected.OrderBy(p => p).ToArray(),
                roots = _plan.roots.ToArray(), candidates = _plan.candidates.ToArray(), retained = _plan.retained.Select(p => p.Key + " : " + p.Value).ToArray() }, true), new UTF8Encoding(false));
        }

        private static string GB(long bytes) => (bytes / 1000000000d).ToString("F3") + " GB";
        private void DrawCapacity(long before, long after, bool actual)
        {
            long removed = Math.Max(0, before - after);
            float fraction = before > 0 ? Mathf.Clamp01((float)(removed / (double)before)) : 0;
            Color remainingColor = new Color(0.22f, 0.57f, 0.90f);
            Color removedColor = new Color(1f, 0.57f, 0.20f);
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField(actual ? T("削除結果（Assets実測）", "Cleanup result (measured Assets)")
                    : T("削除後の容量予測（選択に連動）", "Capacity forecast (based on selection)"), EditorStyles.boldLabel);
                Rect area = GUILayoutUtility.GetRect(100, 108, GUILayout.ExpandWidth(true));
                Vector3 center = new Vector3(area.x + 54, area.y + 54, 0);
                if (Event.current.type == EventType.Repaint)
                {
                    Color previous = Handles.color;
                    Handles.BeginGUI();
                    try
                    {
                        Handles.color = before > 0 ? remainingColor : Color.gray;
                        Handles.DrawSolidDisc(center, Vector3.forward, 44);
                        if (fraction > 0)
                        {
                            Handles.color = removedColor;
                            Handles.DrawSolidArc(center, Vector3.forward, Vector3.up, 360f * fraction, 44);
                        }
                    }
                    finally { Handles.color = previous; Handles.EndGUI(); }
                }
                float left = area.x + 116;
                float width = Math.Max(1, area.width - 116);
                GUI.Label(new Rect(left, area.y + 2, width, 20), T($"削除前のAssets：{GB(before)}", $"Assets before: {GB(before)}"), EditorStyles.boldLabel);
                EditorGUI.DrawRect(new Rect(left, area.y + 32, 12, 12), remainingColor);
                GUI.Label(new Rect(left + 18, area.y + 28, width - 18, 20),
                    actual ? T($"削除後：{GB(after)}", $"After: {GB(after)}") : T($"残る容量：{GB(after)}", $"Remaining: {GB(after)}"));
                EditorGUI.DrawRect(new Rect(left, area.y + 58, 12, 12), removedColor);
                GUI.Label(new Rect(left + 18, area.y + 54, width - 18, 20),
                    T($"減る容量：{GB(removed)}（{fraction * 100:F1}%）", $"Reduction: {GB(removed)} ({fraction * 100:F1}%)"));
                GUI.Label(new Rect(left, area.y + 80, width, 20), T("1 GB = 1,000,000,000 bytes / .meta含む", "1 GB = 1,000,000,000 bytes / includes .meta"), EditorStyles.miniLabel);
                EditorGUILayout.LabelField(T("Assets全体を集計。Library・Packages・バックアップ・ごみ箱は含みません。",
                    "All Assets measured; excludes Library, Packages, backups and trash."), EditorStyles.miniLabel);
                EditorGUILayout.LabelField(T("ディスク空き容量・動作速度の改善量ではありません。容量は調査時点の値です。",
                    "Not a prediction of free disk space or performance. Values reflect the last scan."), EditorStyles.miniLabel);
            }
        }

        internal void Help()
        {
            EditorUtility.DisplayDialog(T("Hierarchy基準の整理", "Hierarchy cleanup"), T(
                "1. 残すアバター・衣装をHierarchyに配置します。非アクティブも残します。\n2. 整理する衣装フォルダを指定します。空欄はAssets全体です。\n3. メニューのScanで自動調査します。保存確認が出た場合は承認後に調査します。不要候補を選択します。\n4. シーンを保存し、下の削除ボタンで確認します。\n5. 削除履歴・再インポートで、親フォルダ名やファイル名を検索できます。TXTの一覧も保存されます。元のPackageを選んで再インポートするか、日時を選んでバックアップを復元します。\n\n使っていないPrefab同士の参照は使用中の根拠にしません。Hierarchyの共有素材・AnimationClip・Prefab接続元とその依存先は残します。Prefab接続元に含まれる素材は、Instanceで外していても残る場合があります。\n\nコード・SDK・Resources・AssetBundle・Addressables等は保護します。名前による動的ロードや独自ツールのGUID文字列は網羅できないため、追加で残す対象へ指定してください。\n\nバックアップはプロジェクト直下のProjectHealthScannerBackups/HierarchyCleanupです。整理範囲内の既存空フォルダと、今回空になった親フォルダも削除します。復元は同じプロジェクトパスで行います。更新の自動通知は未設定です。",
                "1. Keep desired avatars/clothes in the Hierarchy, including inactive ones.\n2. Choose an outfit folder, or leave empty for all Assets.\n3. Scan and select unused candidates by folder or file.\n4. Save scenes, then confirm removal with the bottom button.\n5. Search source folders and filenames in History / reimport. A TXT list is saved. Choose the original package for interactive reimport, or restore a backup by date.\n\nReferences between unused stored prefabs do not make them live. Hierarchy materials, animations, prefab sources and their dependencies are retained. Prefab sources can retain assets removed from an instance.\n\nCode, SDKs, Resources, AssetBundles and known Addressables entries are protected. Name-based loading and custom GUID strings may need explicit keep entries.\n\nBackups are under ProjectHealthScannerBackups/HierarchyCleanup at the project root. Existing empty folders in scope and newly emptied parent folders are removed and restored with the same backup. Restoration requires the same project path. Automatic update notifications are not configured."), "OK");
        }
        private static string Bytes(long bytes) => (bytes / (1024d * 1024d)).ToString("F2") + " MB";
    }
}

