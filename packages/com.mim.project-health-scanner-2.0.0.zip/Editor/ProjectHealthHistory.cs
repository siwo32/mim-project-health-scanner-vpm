using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace ProjectHealthScanner
{
    internal static partial class HierarchyCleanup
    {
        internal const string HistoryFileName = "DeletedAssets.txt";
        internal static string TopFolder(string path)
        {
            var parts = path.Split('/');
            return parts.Length > 2 ? "Assets/" + parts[1] : "Assets (root files)";
        }
        internal static string HistoryState(CleanupBackupItem item) => item.restored ? "復元済み / Restored" :
            item.removed ? "削除済み / Removed" : "削除処理の記録（旧版・中断を含む） / Attempt recorded (legacy or interrupted)";
        internal static void WriteHistory(string directory, CleanupBackup backup)
        {
            var text = new StringBuilder();
            text.AppendLine("Project Health Scanner — 削除履歴 / Removal history");
            text.AppendLine("日時 / Date: " + backup.createdAt);
            text.AppendLine("Project: " + backup.project);
            text.AppendLine("親フォルダ名は削除元です。フォルダ全体を消したとは限りません。");
            text.AppendLine("Parent folders identify the source distribution, not deletion of the entire folder.");
            text.AppendLine("元のPackageは自動特定できません。再インポートでは不要ファイルも戻る場合があります。");
            text.AppendLine("Original package is not identified automatically. Reimport may also restore unwanted files.");
            text.AppendLine("状態はPHSの操作記録です。手動復旧・再インポート後の状態は自動更新しません。");
            text.AppendLine("Status records PHS operations; external restoration/reimport does not update it.");
            foreach (var group in backup.items.Where(i => i.attempted).GroupBy(i => TopFolder(i.path)).OrderBy(g => g.Key))
            {
                text.AppendLine(); text.AppendLine("[" + group.Key + "]");
                foreach (var item in group.OrderBy(i => i.path))
                    text.AppendLine(HistoryState(item) + "\t" + item.path + "\tGUID=" + item.guid);
            }
            text.AppendLine(); text.AppendLine("削除した空フォルダ / Empty-folder removal records");
            foreach (var item in backup.folders.Where(i => i.attempted).OrderBy(i => i.path))
                text.AppendLine(HistoryState(item) + "\t" + item.path + "\tGUID=" + item.guid);
            string file = Path.Combine(directory, HistoryFileName), temp = file + ".tmp";
            File.WriteAllText(temp, text.ToString(), new UTF8Encoding(true));
            if (File.Exists(file)) File.Replace(temp, file, null); else File.Move(temp, file);
        }
        internal static void WriteHistorySafely(string directory, CleanupBackup backup)
        {
            try { WriteHistory(directory, backup); }
            catch (Exception ex) { Debug.LogWarning("[PHS] TXT履歴を書き出せませんでした。manifest.jsonは保持されています。 / TXT history failed; manifest retained. " + ex.Message); }
        }
    }

    public sealed partial class ProjectHealthHierarchyCleanupWindow
    {
        sealed class HistorySession
        {
            public string directory;
            public CleanupBackup backup;
        }
        private readonly List<HistorySession> _history = new List<HistorySession>();
        private readonly List<string> _historyErrors = new List<string>();
        private bool _historyLoaded;
        private int _historyIndex;
        private int _historyPage;
        private string _historySearch = "";
        private Vector2 _historyScroll;
        private bool _showRemovedFolders;
        internal void LoadHistory()
        {
            _history.Clear(); _historyErrors.Clear(); _historyPage = 0; _historyLoaded = true;
            try
            {
                if (Directory.Exists(HierarchyCleanup.BackupRoot))
                    foreach (string dir in Directory.GetDirectories(HierarchyCleanup.BackupRoot).OrderByDescending(p => p, StringComparer.Ordinal))
                    {
                        if (!File.Exists(Path.Combine(dir, "manifest.json"))) continue;
                        try
                        {
                            var backup = HierarchyCleanup.ReadBackup(dir);
                            if (backup.items.Concat(backup.folders).Any(i => i.attempted))
                                _history.Add(new HistorySession { directory = dir, backup = backup });
                        }
                        catch (Exception ex) { _historyErrors.Add(Path.GetFileName(dir) + ": " + ex.Message); }
                    }
            }
            catch (Exception ex) { _historyErrors.Add(ex.Message); }
            _historyIndex = Mathf.Clamp(_historyIndex, 0, Math.Max(0, _history.Count - 1));
        }
        internal void DrawHistory()
        {
            if (!_historyLoaded) LoadHistory();
            EditorGUILayout.HelpBox(T("削除した衣装・商品のフォルダ名とファイル名を確認し、元のunitypackageを再インポートできます。バックアップ復元も利用できます。", "Find removed files and their source folders, then reimport the original unitypackage or use backup restoration."), MessageType.Info);
            if (GUILayout.Button(T("履歴を再読み込み", "Reload history"))) LoadHistory();
            foreach (string error in _historyErrors.Take(3)) EditorGUILayout.HelpBox(error, MessageType.Warning);
            if (_history.Count == 0) { EditorGUILayout.HelpBox(T("削除履歴はありません。", "No removal history found."), MessageType.Info); return; }
            EditorGUI.BeginChangeCheck();
            _historyIndex = EditorGUILayout.Popup(T("削除した日時", "Removal session"), _historyIndex,
                _history.Select(h => h.backup.createdAt + " / " + h.backup.items.Count(i => i.attempted) + T("ファイル", " files")).ToArray());
            _historySearch = EditorGUILayout.TextField(new GUIContent(T("履歴内を検索", "Search history"), T("ファイル名・フォルダ名・GUID", "Filename, folder or GUID")), _historySearch);
            if (EditorGUI.EndChangeCheck()) { _historyPage = 0; _historyScroll = Vector2.zero; }
            var session = _history[_historyIndex];
            var backup = session.backup;
            string search = (_historySearch ?? "").Trim();
            var matching = backup.items.Where(i => i.attempted && (search.Length == 0 ||
                i.path.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0 ||
                (i.guid ?? "").IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0)).ToArray();
            EditorGUILayout.LabelField(T("削除元の親フォルダ（Assets直下）", "Source folders directly under Assets"), EditorStyles.boldLabel);
            var groups = matching.GroupBy(i => HierarchyCleanup.TopFolder(i.path)).OrderBy(g => g.Key).ToArray();
            EditorGUILayout.LabelField(string.Join(" / ", groups.Take(12).Select(g => g.Key + " (" + g.Count() + ")")) +
                (groups.Length > 12 ? T(" …検索で絞り込んでください", " …refine the search") : ""), EditorStyles.wordWrappedLabel);
            EditorGUILayout.HelpBox(T("親フォルダ全体を削除したという意味ではありません。検索は選択した日時の履歴が対象です。状態はPHSの操作記録で、再インポート後の状態は自動判定しません。", "These folders identify where files came from. Search covers the selected session. Status records PHS operations, not the current state after reimport."), MessageType.None);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(T("削除一覧TXTを開く", "Open removal TXT")))
                    try { HierarchyCleanup.WriteHistory(session.directory, backup); EditorUtility.OpenWithDefaultApp(Path.Combine(session.directory, HierarchyCleanup.HistoryFileName)); }
                    catch (Exception ex) { EditorUtility.DisplayDialog("PHS", ex.Message, "OK"); }
                if (GUILayout.Button(T("履歴の保存先を開く", "Open history folder"))) EditorUtility.RevealInFinder(session.directory);
            }
            _showRemovedFolders = EditorGUILayout.Foldout(_showRemovedFolders, T("削除した空フォルダを確認する", "View removed empty folders"), true);
            _historyScroll = EditorGUILayout.BeginScrollView(_historyScroll);
            if (_showRemovedFolders)
            {
                var folders = backup.folders.Where(f => f.attempted).ToArray();
                foreach (var folder in folders.Take(100)) EditorGUILayout.LabelField(folder.path, EditorStyles.wordWrappedMiniLabel);
                if (folders.Length > 100) EditorGUILayout.LabelField(T("全件はTXTで確認できます。", "See TXT for all folders."));
            }
            int pages = Math.Max(1, (matching.Length + 49) / 50);
            _historyPage = Mathf.Clamp(_historyPage, 0, pages - 1);
            foreach (var item in matching.Skip(_historyPage * 50).Take(50))
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    EditorGUILayout.LabelField(Path.GetFileName(item.path), EditorStyles.boldLabel);
                    EditorGUILayout.LabelField(item.path, EditorStyles.wordWrappedMiniLabel);
                    EditorGUILayout.LabelField(HierarchyCleanup.HistoryState(item), EditorStyles.miniLabel);
                    if (GUILayout.Button(T("パスをコピー", "Copy path"))) EditorGUIUtility.systemCopyBuffer = item.path;
                }
            if (matching.Length == 0) EditorGUILayout.LabelField(T("一致するファイルはありません。", "No matching files."));
            EditorGUILayout.EndScrollView();
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(_historyPage == 0)) if (GUILayout.Button(T("前へ", "Previous"))) _historyPage--;
                GUILayout.Label(($"{_historyPage + 1} / {pages} — {matching.Length}") + T("件", " files"));
                using (new EditorGUI.DisabledScope(_historyPage + 1 >= pages)) if (GUILayout.Button(T("次へ", "Next"))) _historyPage++;
            }
            EditorGUILayout.HelpBox(T("元のPackageを自分で選択してください。同じ名前でも別商品・別バージョンの場合があります。再インポートすると、今回消した以外の不要ファイルも戻る場合があります。", "Choose the original package yourself and verify its product/version. Reimport can also bring back unwanted files outside this history."), MessageType.Info);
            bool busy = EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode;
            using (new EditorGUI.DisabledScope(busy))
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(T("元のunitypackageを選んで再インポート", "Select original unitypackage")))
                {
                    string path = EditorUtility.OpenFilePanel(T("元の商品Packageを選択", "Choose the original package"), "", "unitypackage");
                    if (!string.IsNullOrEmpty(path)) AssetDatabase.ImportPackage(path, true);
                }
                using (new EditorGUI.DisabledScope(!backup.items.Concat(backup.folders).Any(i => i.attempted && !i.restored)))
                    if (GUILayout.Button(T("この日時のバックアップを復元", "Restore this backup")))
                    {
                        _latestBackup = session.directory; Restore(); LoadHistory();
                    }
            }
        }
    }
}
