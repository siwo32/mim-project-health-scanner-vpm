// Retained at the original GUID so upgrading removes the old optimizer implementation.
// Previous texture settings backups are left untouched.
using UnityEditor;
namespace ProjectHealthScanner
{
    public sealed class ProjectHealthTextureOptimizerWindow : EditorWindow
    {
        public static void Open() => ProjectHealthScannerWindow.Open();
        private void OnGUI()
        {
            EditorGUILayout.HelpBox("PHSは不要ファイル整理専用になりました。 / PHS now focuses on unused-file cleanup.", MessageType.Info);
            if (UnityEngine.GUILayout.Button("PHS / Scan")) { Open(); Close(); }
        }
    }
}